using System;

namespace Stingray.Entidades
{
    public class Turma
    {
        public int IdTurma { get; set; }
        public string Modalidade { get; set; }
        public string DiaSemana { get; set; }
        public TimeSpan HorarioInicio { get; set; }
        public TimeSpan HorarioFim { get; set; }
        public int Capacidade { get; set; }
        public int IdProfessor { get; set; }
        public string NomeProfessor { get; set; }
        public int QuantidadeParticipantes { get; set; }
    }
}
