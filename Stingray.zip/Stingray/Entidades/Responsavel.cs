namespace Stingray.Entidades
{
    public class Responsavel
    {
        public int IdResponsavel { get; set; }
        public string Observacao { get; set; }
    }
}
