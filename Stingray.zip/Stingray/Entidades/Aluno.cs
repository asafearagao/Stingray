namespace Stingray.Entidades
{
    public class Aluno
    {
        public int IdAluno { get; set; }
        public string Observacao { get; set; }

        public Pessoa Pessoa { get; set; }
        public Endereco Endereco { get; set; }
        public Telefone Telefone { get; set; }

        public int IdMatricula { get; set; }
        public System.DateTime DataMatricula { get; set; }
        public byte DiaVencimento { get; set; }
        public string Situacao { get; set; }

        public string Modalidades { get; set; }
        public string Professores { get; set; }
    }
}
