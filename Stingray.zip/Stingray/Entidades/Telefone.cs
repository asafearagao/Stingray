namespace Stingray.Entidades
{
    public class Telefone
    {
        public int IdTelefone { get; set; }
        public string NumeroTelefone { get; set; }
        public int IdPessoa { get; set; }
    }
}
