﻿using System;
using System.Windows.Forms;
using Stingray.Formularios;
using Stingray.Servicos;

namespace Stingray {
    internal static class Program {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try {

                var autenticacao = new AutenticacaoServico();
                string mensagemConexao;

                if (!autenticacao.TestarConexao(out mensagemConexao))
                {
                    MessageBox.Show(
                        mensagemConexao + Environment.NewLine + Environment.NewLine +
                        "Verifique se o MySQL84 está em execução e se a credencial do banco foi configurada para esta conta do Windows.",
                        "Banco de dados indisponível",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                // Na primeira execução, se cria a primeira conta
                if (!autenticacao.ExisteUsuarioCadastrado())
                {
                    using (var primeiroAcesso = new ContaAcessoForm(true, null))
                    {
                        if (primeiroAcesso.ShowDialog() != DialogResult.OK)
                            return;
                    }
                }

                Application.Run(new LoginForm());
            }
            catch (Exception erro)
            {
                MessageBox.Show(
                    "Não foi possível iniciar o Stingray." + Environment.NewLine + erro.Message,
                    "Falha na inicialização",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
