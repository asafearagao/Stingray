using System;
using System.Drawing;
using System.Windows.Forms;

namespace Stingray {
    internal static class EstiloPopup {
        // Cores padrões Popup
        private static readonly Color Fundo = Color.FromArgb(248, 250, 252);
        private static readonly Color Texto = Color.FromArgb(31, 41, 55);
        private static readonly Color TextoSuave = Color.FromArgb(100, 116, 139);

        public static void Aplicar(Form formulario) {
            if (formulario == null)
                return;

            formulario.StartPosition = FormStartPosition.CenterParent;
            formulario.FormBorderStyle = FormBorderStyle.FixedDialog;
            formulario.MinimizeBox = false;
            formulario.MaximizeBox = false;
            formulario.ShowInTaskbar = false;
            formulario.BackColor = Fundo;
            formulario.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);

            // Filete azul discreto para identificar visualmente as janelas do Stingray.
            formulario.Paint += delegate (object sender, PaintEventArgs e) {
                using (Brush pincel = new SolidBrush(VisualPadrao.Azul))
                    e.Graphics.FillRectangle(pincel, 0, 0, formulario.ClientSize.Width, 3);
            };

            AplicarAosControles(formulario);
        }

        public static void ConfigurarCabecalho(Label titulo, Label descricao) {
            if (titulo != null) {
                titulo.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
                titulo.ForeColor = Texto;
            }

            if (descricao != null) {
                descricao.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
                descricao.ForeColor = TextoSuave;
            }
        }

        private static void AplicarAosControles(Control pai) {
            foreach (Control controle in pai.Controls) {
                if (controle is TextBox || controle is MaskedTextBox) {
                    controle.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
                    controle.ForeColor = Texto;
                    controle.BackColor = Color.White;
                }
                else if (controle is ComboBox combo) {
                    combo.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
                    combo.ForeColor = Texto;
                    combo.BackColor = Color.White;
                    combo.FlatStyle = FlatStyle.Flat;
                }
                else if (controle is CheckedListBox listaMarcacao) {
                    listaMarcacao.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
                    listaMarcacao.ForeColor = Texto;
                    listaMarcacao.BackColor = Color.White;
                    listaMarcacao.BorderStyle = BorderStyle.FixedSingle;
                    listaMarcacao.CheckOnClick = true;
                    listaMarcacao.IntegralHeight = false;
                    listaMarcacao.ItemHeight = 26;
                }
                else if (controle is ListBox lista) {
                    lista.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
                    lista.ForeColor = Texto;
                    lista.BackColor = Color.White;
                    lista.BorderStyle = BorderStyle.FixedSingle;
                    lista.IntegralHeight = false;
                    lista.ItemHeight = 28;
                }
                else if (controle is DateTimePicker data) {
                    data.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
                }
                else if (controle is RoundedButton botaoArredondado) {
                    ConfigurarBotao(botaoArredondado, EhAcaoPrincipal(botaoArredondado.Text));
                }
                else if (controle is Button seta &&
                         string.Equals(Convert.ToString(seta.Tag), "SetaComboDialogo", StringComparison.Ordinal)) {
                    seta.FlatStyle = FlatStyle.Flat;
                    seta.UseVisualStyleBackColor = false;
                    seta.Cursor = Cursors.Hand;
                    seta.BackColor = Color.White;
                    seta.FlatAppearance.BorderSize = 0;
                    seta.FlatAppearance.MouseOverBackColor = Color.FromArgb(239, 246, 255);
                    seta.FlatAppearance.MouseDownBackColor = Color.FromArgb(219, 234, 254);
                }
                else if (controle is Button botao) {
                    ConfigurarBotaoPadrao(botao, EhAcaoPrincipal(botao.Text));
                }
                if (controle.HasChildren)
                    AplicarAosControles(controle);
            }
        }

        private static bool EhAcaoPrincipal(string texto) {
            if (string.IsNullOrWhiteSpace(texto))
                return false;

            return texto.StartsWith("Salvar", StringComparison.CurrentCultureIgnoreCase) ||
                   texto.StartsWith("Adicionar", StringComparison.CurrentCultureIgnoreCase) ||
                   texto.StartsWith("Criar", StringComparison.CurrentCultureIgnoreCase) ||
                   texto.StartsWith("Confirmar", StringComparison.CurrentCultureIgnoreCase);
        }

        private static void ConfigurarBotao(RoundedButton botao, bool principal) {
            botao.CornerRadius = 7;
            botao.FlatStyle = FlatStyle.Flat;
            botao.UseVisualStyleBackColor = false;
            botao.Cursor = Cursors.Hand;
            botao.Font = new Font("Segoe UI", 9F,
                principal ? FontStyle.Bold : FontStyle.Regular, GraphicsUnit.Point);

            if (principal) {
                botao.BackColor = VisualPadrao.Azul;
                botao.ForeColor = Color.White;
                botao.FlatAppearance.BorderSize = 0;
                botao.FlatAppearance.BorderColor = VisualPadrao.Azul;
                botao.FlatAppearance.MouseOverBackColor = VisualPadrao.AzulHover;
                botao.FlatAppearance.MouseDownBackColor = VisualPadrao.AzulPressionado;
            }
            else {
                botao.BackColor = Color.White;
                botao.ForeColor = Texto;
                botao.FlatAppearance.BorderSize = 1;
                botao.FlatAppearance.BorderColor = VisualPadrao.BordaCampo;
                botao.FlatAppearance.MouseOverBackColor = VisualPadrao.AzulClaro;
                botao.FlatAppearance.MouseDownBackColor = Color.FromArgb(219, 234, 254);
            }
        }

        private static void ConfigurarBotaoPadrao(Button botao, bool principal) {
            botao.FlatStyle = FlatStyle.Flat;
            botao.UseVisualStyleBackColor = false;
            botao.Cursor = Cursors.Hand;
            botao.Font = new Font("Segoe UI", 9F,
                principal ? FontStyle.Bold : FontStyle.Regular, GraphicsUnit.Point);

            if (principal) {
                botao.BackColor = VisualPadrao.Azul;
                botao.ForeColor = Color.White;
                botao.FlatAppearance.BorderSize = 0;
                botao.FlatAppearance.MouseOverBackColor = VisualPadrao.AzulHover;
                botao.FlatAppearance.MouseDownBackColor = VisualPadrao.AzulPressionado;
            }
            else {
                botao.BackColor = Color.White;
                botao.ForeColor = Texto;
                botao.FlatAppearance.BorderSize = 1;
                botao.FlatAppearance.BorderColor = VisualPadrao.BordaCampo;
                botao.FlatAppearance.MouseOverBackColor = VisualPadrao.AzulClaro;
                botao.FlatAppearance.MouseDownBackColor = Color.FromArgb(219, 234, 254);
            }
        }
    }
}
