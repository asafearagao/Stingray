using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Http;
using System.ComponentModel;
using System.Windows.Forms;
using Stingray.Entidades;
using Stingray.Formularios;
using Stingray.Servicos;

namespace Stingray {
    [DesignerCategory("Form")]
    public partial class ConfiguracoesForm : Form {
        private Panel cartaoWhatsApp;
        private ToggleSwitch chkWhatsAppAtivado;
        private Label lblEstadoWhatsApp;
        private Label lblDescricaoWhatsApp;
        private RoundedButton btnAbrirWhatsApp;
        private PictureBox iconeWhatsApp;
        private Timer timerEstadoWhatsApp;
        private bool verificacaoEmAndamento;
        private bool carregandoLogo;
        private DateTime ultimaTentativaLogo = DateTime.MinValue;
        private readonly Usuario usuarioAtual;
        private Panel cartaoConta;

        public ConfiguracoesForm() : this(null) {
        }

        public ConfiguracoesForm(Usuario usuarioAtual) {
            this.usuarioAtual = usuarioAtual;
            InitializeComponent();
            bool emDesignTime = ModoDesign.EstaEmModoDesign(this);
            cartaoWhatsApp.BorderStyle = BorderStyle.None;
            cartaoWhatsApp.Paint -= CartaoWhatsApp_Paint;
            cartaoWhatsApp.Paint += CartaoWhatsApp_Paint;
            iconeWhatsApp.Paint += IconeWhatsApp_Paint;

            if (emDesignTime) {
                // O cartão da conta é criado aqui para que também apareça na pré-visualização.
                CriarCartaoConta(false);
                lblEstadoWhatsApp.Text = "Pré-visualização";
                lblDescricaoWhatsApp.Text = "A integração será verificada durante a execução do aplicativo.";
                btnAbrirWhatsApp.Visible = true;
                AjustarPosicaoCartoes();
                return;
            }

            if (usuarioAtual != null)
                CriarCartaoConta(true);

            btnAbrirWhatsApp.Visible = false;
            chkWhatsAppAtivado.Checked = WhatsAppServico.EstaAtivado();
            chkWhatsAppAtivado.CheckedChanged += ChkWhatsAppAtivado_CheckedChanged;
            btnAbrirWhatsApp.Click += BtnAbrirWhatsApp_Click;
            _ = CarregarLogoWhatsAppAsync(iconeWhatsApp);

            timerEstadoWhatsApp = new Timer();
            timerEstadoWhatsApp.Interval = 5000;
            timerEstadoWhatsApp.Tick += async delegate {
                await AtualizarEstadoWhatsAppAsync();

                if (iconeWhatsApp.Image == null && !carregandoLogo &&
                    DateTime.Now - ultimaTentativaLogo >= TimeSpan.FromSeconds(30)) {
                    ultimaTentativaLogo = DateTime.Now;
                    await CarregarLogoWhatsAppAsync(iconeWhatsApp);
                }
            };
            timerEstadoWhatsApp.Start();
            AtualizarVisualEstado();

            painelConteudo.Resize += delegate { AjustarPosicaoCartoes(); };
            AjustarPosicaoCartoes();
            FormClosed += delegate {
                if (timerEstadoWhatsApp != null) {
                    timerEstadoWhatsApp.Stop();
                    timerEstadoWhatsApp.Dispose();
                }
            };
        }



        // Mantém os cartões lado a lado
        private void AjustarPosicaoCartoes() {
            int larguraCartao = Math.Max(360, (painelConteudo.ClientSize.Width - 72) / 2);

            cartaoWhatsApp.Width = larguraCartao;
            chkWhatsAppAtivado.Left = cartaoWhatsApp.Width - chkWhatsAppAtivado.Width - 18;

            if (cartaoConta == null)
                return;

            cartaoConta.Width = larguraCartao;
            cartaoConta.Left = cartaoWhatsApp.Right + 24;
        }

        private void CriarCartaoConta(bool permitirAlteracao) {
            cartaoConta = new Panel {
                BackColor = Color.White,
                BorderStyle = BorderStyle.None,
                Location = new Point(cartaoWhatsApp.Right + 24, 28),
                Size = new Size(440, 166),
                Name = "cartaoConta"
            };
            cartaoConta.Paint += delegate (object sender, PaintEventArgs e) {
                VisualPadrao.DesenharBordaCartao(e.Graphics, cartaoConta.ClientRectangle);
            };

            var lblTituloConta = new Label {
                AutoSize = true,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(31, 41, 55),
                Location = new Point(18, 16),
                Text = "Conta do sistema"
            };

            var lblDescricaoConta = new Label {
                AutoSize = false,
                Font = new Font("Segoe UI", 8.5F, FontStyle.Regular),
                ForeColor = Color.FromArgb(107, 114, 128),
                Location = new Point(18, 55),
                Size = new Size(390, 34),
                Text = "Altere o nome de usuário e a senha usados para entrar no Stingray."
            };

            var btnAlterarConta = new RoundedButton {
                BackColor = VisualPadrao.Azul,
                CornerRadius = 7,
                Cursor = Cursors.Hand,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI Semibold", 9F, FontStyle.Regular),
                ForeColor = Color.White,
                Location = new Point(18, 101),
                Size = new Size(205, 34),
                Text = "Alterar usuário e senha",
                UseVisualStyleBackColor = false
            };
            btnAlterarConta.FlatAppearance.BorderSize = 0;
            btnAlterarConta.FlatAppearance.MouseOverBackColor = VisualPadrao.AzulHover;
            btnAlterarConta.FlatAppearance.MouseDownBackColor = VisualPadrao.AzulPressionado;
            if (permitirAlteracao)
                btnAlterarConta.Click += BtnAlterarConta_Click;

            cartaoConta.Controls.Add(lblTituloConta);
            cartaoConta.Controls.Add(lblDescricaoConta);
            cartaoConta.Controls.Add(btnAlterarConta);
            painelConteudo.Controls.Add(cartaoConta);
        }

        private void BtnAlterarConta_Click(object sender, EventArgs e) {
            using (var formulario = new ContaAcessoForm(false, usuarioAtual)) {
                formulario.ShowDialog(FindForm());
            }
        }

        private void IconeWhatsApp_Paint(object sender, PaintEventArgs e) {
            if (iconeWhatsApp.Image != null)
                return;

            Graphics grafico = e.Graphics;
            grafico.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Rectangle area = new Rectangle(2, 2, Math.Max(1, iconeWhatsApp.Width - 4), Math.Max(1, iconeWhatsApp.Height - 4));
            using (SolidBrush fundo = new SolidBrush(Color.FromArgb(220, 252, 231)))
                grafico.FillEllipse(fundo, area);

            using (Pen telefone = new Pen(Color.FromArgb(22, 163, 74), 2.1F)) {
                telefone.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                telefone.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                telefone.LineJoin = System.Drawing.Drawing2D.LineJoin.Round;
                float x = iconeWhatsApp.Width / 2F;
                float y = iconeWhatsApp.Height / 2F;
                grafico.DrawArc(telefone, x - 7F, y - 7F, 14F, 14F, 125F, 105F);
                grafico.DrawLine(telefone, x - 5.8F, y - 5.1F, x - 2.8F, y - 2.4F);
                grafico.DrawLine(telefone, x + 2.5F, y + 2.5F, x + 5.1F, y + 5.1F);
            }
        }

        private void CartaoWhatsApp_Paint(object sender, PaintEventArgs e) {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Rectangle area = cartaoWhatsApp.ClientRectangle;
            area.Width -= 1;
            area.Height -= 1;
            using (var path = new System.Drawing.Drawing2D.GraphicsPath()) {
                int raio = 8;
                path.AddArc(area.X, area.Y, raio, raio, 180, 90);
                path.AddArc(area.Right - raio, area.Y, raio, raio, 270, 90);
                path.AddArc(area.Right - raio, area.Bottom - raio, raio, raio, 0, 90);
                path.AddArc(area.X, area.Bottom - raio, raio, raio, 90, 90);
                path.CloseFigure();
                using (var pen = new Pen(VisualPadrao.BordaCartao, 1F))
                    e.Graphics.DrawPath(pen, path);
            }
        }

        private void ChkWhatsAppAtivado_CheckedChanged(object sender, EventArgs e) {
            WhatsAppServico.DefinirAtivado(chkWhatsAppAtivado.Checked);
            AtualizarVisualEstado();
            if (chkWhatsAppAtivado.Checked)
                _ = AtualizarEstadoWhatsAppAsync();
        }

        // Consulta a conexão sem alterar a fila de mensagens
        private async System.Threading.Tasks.Task AtualizarEstadoWhatsAppAsync() {
            if (verificacaoEmAndamento || IsDisposed || !IsHandleCreated)
                return;

            verificacaoEmAndamento = true;
            try {
                if (!WhatsAppServico.EstaAtivado()) {
                    AtualizarVisualEstado();
                    return;
                }

                // Mantém o único botão de ação visível enquanto a integração estiver ativa
                btnAbrirWhatsApp.Visible = true;

                bool internet = await WhatsAppServico.VerificarInternetAsync();
                if (!internet) {
                    lblEstadoWhatsApp.Text = "Sem internet";
                    lblEstadoWhatsApp.ForeColor = Color.FromArgb(185, 28, 28);
                    lblDescricaoWhatsApp.Text = "Verifique sua conexão com a internet.";
                    // Não alteramos o estado de autenticação salvo só porque a internet caiu
                    return;
                }

                bool conectadoAgora = await WhatsAppServico.VerificarWhatsAppAsync();
                if (WhatsAppServico.SessaoConfirmadaAgora && conectadoAgora) {
                    lblEstadoWhatsApp.Text = "Conectado";
                    lblEstadoWhatsApp.ForeColor = Color.FromArgb(22, 101, 52);
                    lblDescricaoWhatsApp.Text = "WhatsApp Web autenticado e pronto.";

                } else if (WhatsAppServico.SessaoConfirmadaAgora && !conectadoAgora) {
                    // A verificação encontrou claramente a tela de QR Code/login
                    lblEstadoWhatsApp.Text = "Desconectado";
                    lblEstadoWhatsApp.ForeColor = Color.FromArgb(180, 83, 9);
                    lblDescricaoWhatsApp.Text = "Abra o navegador e leia o QR Code pelo celular.";

                } else if (WhatsAppServico.ConexaoWhatsApp) {
                    // Preserva o estado salvo durante falhas transitórias. A sessão é
                    // confirmada novamente pelo navegador assim que ele responder
                    lblEstadoWhatsApp.Text = "Conectado";
                    lblEstadoWhatsApp.ForeColor = Color.FromArgb(22, 101, 52);
                    lblDescricaoWhatsApp.Text = "A sessão será verificada automaticamente.";

                } else {
                    lblEstadoWhatsApp.Text = "Verificando sessão...";
                    lblEstadoWhatsApp.ForeColor = Color.FromArgb(107, 114, 128);
                    lblDescricaoWhatsApp.Text = "A página ainda está carregando ou aguardando autenticação.";
                }

            } catch {
                // Uma falha de consulta não equivale a logout. Preserva o estado salvo
                if (WhatsAppServico.ConexaoInternet) {
                    lblEstadoWhatsApp.Text = WhatsAppServico.ConexaoWhatsApp
                        ? "Conectado"
                        : "Não foi possível verificar";
                    lblEstadoWhatsApp.ForeColor = Color.FromArgb(107, 114, 128);
                    lblDescricaoWhatsApp.Text = WhatsAppServico.ConexaoWhatsApp
                        ? "A sessão será verificada automaticamente."
                        : "Abra o WhatsApp Web para autenticar a sessão.";

                } else {
                    lblEstadoWhatsApp.Text = "Sem internet";
                    lblEstadoWhatsApp.ForeColor = Color.FromArgb(185, 28, 28);
                    lblDescricaoWhatsApp.Text = "Verifique sua conexão com a internet.";
                }

                if (WhatsAppServico.EstaAtivado())
                    btnAbrirWhatsApp.Visible = true;

            } finally {
                verificacaoEmAndamento = false;
            }
        }

        // Atualiza a aparência conforme o estado da integração
        private void AtualizarVisualEstado() {
            if (!WhatsAppServico.EstaAtivado()) {
                lblEstadoWhatsApp.Text = "Inativo";
                lblEstadoWhatsApp.ForeColor = Color.FromArgb(107, 114, 128);
                lblDescricaoWhatsApp.Text = "A integração está desligada.";
                btnAbrirWhatsApp.Visible = false;

            } else {
                btnAbrirWhatsApp.Visible = true;

                if (!WhatsAppServico.ConexaoInternet) {
                    lblEstadoWhatsApp.Text = "Verificando conexão...";
                    lblEstadoWhatsApp.ForeColor = Color.FromArgb(107, 114, 128);
                    lblDescricaoWhatsApp.Text = WhatsAppServico.ConexaoWhatsApp
                        ? "A sessão será verificada quando a internet voltar."
                        : "Verifique sua conexão com a internet.";

                } else if (!WhatsAppServico.SessaoConfirmadaAgora && WhatsAppServico.ConexaoWhatsApp) {
                    lblEstadoWhatsApp.Text = "Conectado";
                    lblEstadoWhatsApp.ForeColor = Color.FromArgb(22, 101, 52);
                    lblDescricaoWhatsApp.Text = "A sessão será verificada automaticamente.";

                } else {
                    lblEstadoWhatsApp.Text = WhatsAppServico.ConexaoWhatsApp
                        ? "Conectado"
                        : "Verificando sessão...";
                    lblEstadoWhatsApp.ForeColor = WhatsAppServico.ConexaoWhatsApp
                        ? Color.FromArgb(22, 101, 52)
                        : Color.FromArgb(107, 114, 128);
                    lblDescricaoWhatsApp.Text = "Abra o WhatsApp Web para acessar a sessão.";
                }
            }
        }

        // Baixa e armazena localmente a logo do WhatsApp
        private async System.Threading.Tasks.Task CarregarLogoWhatsAppAsync(PictureBox pictureBox) {
            if (carregandoLogo || IsDisposed || pictureBox == null || pictureBox.IsDisposed)
                return;

            carregandoLogo = true;
            ultimaTentativaLogo = DateTime.Now;
            // Usa o arquivo PNG do logotipo publicado na Wikimedia Commons
            string[] urlsLogo = new string[] {
                "https://thumb.wikimedia.org/wikipedia/commons/thumb/5/5e/WhatsApp_icon.png/250px-WhatsApp_icon.png?utm_campaign=index&utm_content=thumbnail&utm_source=commons.wikimedia.org",
                "https://upload.wikimedia.org/wikipedia/commons/5/5e/WhatsApp_icon.png"
            };
            string pastaCache = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Stingray", "Assets");
            string caminhoLogo = Path.Combine(pastaCache, "whatsapp-icon-v2.png");

            try {
                if (!File.Exists(caminhoLogo)) {
                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                    Directory.CreateDirectory(pastaCache);
                    byte[] bytes = null;
                    Exception erroDownload = null;
                    using (HttpClient cliente = new HttpClient()) {
                        cliente.Timeout = System.TimeSpan.FromSeconds(8);
                        cliente.DefaultRequestHeaders.UserAgent.ParseAdd("StingrayApp/1.0");
                        foreach (string urlLogo in urlsLogo) {
                            try {
                                bytes = await cliente.GetByteArrayAsync(urlLogo);
                                if (bytes != null && bytes.Length > 1000)
                                    break;
                                bytes = null;

                            } catch (Exception ex) {
                                erroDownload = ex;
                            }
                        }
                    }

                    if (bytes == null)
                        throw new InvalidOperationException("Não foi possível baixar a imagem do logotipo do WhatsApp.", erroDownload);

                    Directory.CreateDirectory(pastaCache);
                    File.WriteAllBytes(caminhoLogo, bytes);
                }

                if (IsDisposed || pictureBox.IsDisposed)
                    return;

                using (Image imagem = Image.FromFile(caminhoLogo)) {
                    pictureBox.Image = new Bitmap(imagem);
                }

            } catch {
                // Se o cache estiver corrompido, remova-o para permitir novo download depois
                try {
                    if (File.Exists(caminhoLogo)) File.Delete(caminhoLogo);

                } catch {

                }
                // Sem internet no primeiro uso, não colocamos nada
                if (!IsDisposed && !pictureBox.IsDisposed)
                    pictureBox.Image = null;

            } finally {
                carregandoLogo = false;
            }
        }

        // Abre o WhatsApp Web sem enviar mensagens
        private async void BtnAbrirWhatsApp_Click(object sender, EventArgs e) {
            btnAbrirWhatsApp.Enabled = false;
            btnAbrirWhatsApp.Text = "Abrindo navegador...";
            try {
                bool abriu = await WhatsAppServico.PrepararWhatsAppAsync();
                if (!abriu) {
                    MessageBox.Show(this,
                        "Não foi possível abrir o WhatsApp Web.\r\n\r\n" +
                        (String.IsNullOrWhiteSpace(WhatsAppServico.UltimoErro)
                            ? "Nenhum detalhe de erro foi informado."
                            : WhatsAppServico.UltimoErro),
                        "WhatsApp Web", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            } catch (Exception ex) {
                MessageBox.Show(this, ex.ToString(), "WhatsApp Web",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            } finally {
                if (!IsDisposed) {
                    btnAbrirWhatsApp.Enabled = true;
                    btnAbrirWhatsApp.Text = "Abrir WhatsApp Web";
                    await AtualizarEstadoWhatsAppAsync();
                }
            }
        }

        private void PainelConteudo_Paint(object sender, PaintEventArgs e) {
            VisualPadrao.DesenharBordaCartao(e.Graphics, painelConteudo.ClientRectangle);
        }
    }
}
