using System;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Stingray.Entidades;
using Stingray.DadosTela;
using Stingray.Servicos;

namespace Stingray
{
    [System.ComponentModel.DesignerCategory("Form")]
    public partial class AlunoCadastroForm : Form
    {
        private readonly FichaAluno alunoExistente;
        private readonly AlunoServico alunoServico = new AlunoServico();
        private readonly ConsultaCepServico consultaCepServico = new ConsultaCepServico();
        private ResultadoConsultaCep enderecoCepAtual;
        private string cepOriginal;

        public AlunoCadastroForm()
        {
            InitializeComponent();
        }

        // Construtor que recebe uma ficha de aluno existente para edição
        public AlunoCadastroForm(FichaAluno aluno) : this()
        {
            alunoExistente = aluno;
            bool editando = alunoExistente != null;

            // Configura o título e os textos dos botões de acordo com o contexto (novo ou edição)
            Text = editando ? "Editar aluno" : "Novo aluno";
            lblTitulo.Text = editando ? "Editar Aluno" : "Novo Aluno";
            btnSalvar.Text = editando ? "Salvar alterações" : "Salvar aluno";

            ConfigurarCampos();
            if (editando)
                PreencherCampos(alunoExistente);

            dtpNascimento.ValueChanged += delegate { AtualizarCampoResponsavelPorIdade(); };
            btnConsultarCep.Click += BtnConsultarCep_Click;
            txtCep.TextChanged += TxtCep_TextChanged;
            btnConsultarCep.Paint += BtnConsultarCep_Paint;
            btnSalvar.Click += BtnSalvar_Click;
            btnCancelar.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
            Shown += delegate { txtNome.Focus(); };

            AtualizarCampoResponsavelPorIdade();
        }

        // Configura os campos de entrada com limites de caracteres
        private void ConfigurarCampos()
        {
            ConfigurarFormatacaoProgressiva(txtTelefone, FormatarTelefone, 11);
            ConfigurarFormatacaoProgressiva(txtCep, FormatarCep, 8);
            ConfigurarFormatacaoProgressiva(txtCpf, FormatarCpf, 11);
            txtRg.MaxLength = 14;
            txtComplemento.MaxLength = 50;
        }

        // Preenche os campos do formulário com os dados do aluno existente
        private void PreencherCampos(FichaAluno aluno)
        {
            txtNome.Text = aluno.Nome ?? string.Empty;
            dtpNascimento.Value = aluno.DataNascimento < dtpNascimento.MinDate ||
                aluno.DataNascimento > dtpNascimento.MaxDate ? DateTime.Today : aluno.DataNascimento;
            txtTelefone.Text = ExtrairDigitos(aluno.Telefone);
            txtNumero.Text = aluno.Numero ?? string.Empty;
            txtCep.Text = ExtrairDigitos(aluno.Cep);
            cepOriginal = ExtrairDigitos(aluno.Cep);
            txtComplemento.Text = aluno.Complemento ?? string.Empty;
            txtResponsavel.Text = aluno.Responsavel ?? string.Empty;
            txtCpf.Text = ExtrairDigitos(aluno.Cpf);
            txtRg.Text = aluno.Rg ?? string.Empty;
            txtEmail.Text = aluno.Email ?? string.Empty;
            nudDiaVencimento.Value = Math.Max(nudDiaVencimento.Minimum,
                Math.Min(nudDiaVencimento.Maximum, aluno.DiaVencimento));
        }

        private void AtualizarCampoResponsavelPorIdade()
        {
            // Habilita ou desabilita o campo de responsável com base na idade do aluno
            bool maiorDeIdade = CalcularIdade(dtpNascimento.Value) >= 18;
            if (maiorDeIdade)
            {
                txtResponsavel.Clear();
                txtResponsavel.Enabled = false;
                txtResponsavel.BackColor = System.Drawing.SystemColors.Control;
            }
            else
            {
                txtResponsavel.Enabled = true;
                txtResponsavel.BackColor = System.Drawing.Color.White;
            }
        }

        // Evento de clique do botão de consulta de CEP
        private async void BtnConsultarCep_Click(object sender, EventArgs e)
        {
            await ConsultarCepAsync();
        }

        // Se o CEP foi alterado, fazer uma nova consulta
        private void TxtCep_TextChanged(object sender, EventArgs e)
        {
            if (!string.Equals(ExtrairDigitos(txtCep.Text), cepOriginal, StringComparison.Ordinal))
                enderecoCepAtual = null;
        }

        // Evento de pintura do botão de consulta de CEP para desenhar o ícone
        private void BtnConsultarCep_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using (System.Drawing.Pen caneta = new System.Drawing.Pen(VisualPadrao.TextoPrincipal, 1.8F))
            {
                caneta.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                caneta.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                e.Graphics.DrawEllipse(caneta, 7, 5, 10, 10);
                e.Graphics.DrawLine(caneta, 16, 14, 22, 20);
            }
        }

        // Consulta o CEP informado e atualiza os campos de endereço com os dados retornados
        private async Task ConsultarCepAsync()
        {
            string cep = ExtrairDigitos(txtCep.Text);
            // Valida se o CEP possui 8 dígitos antes de realizar a consulta
            if (cep.Length != 8)
            {
                MessageBox.Show(this, "Informe os oito dígitos do CEP antes de consultar.",
                    "Consulta de CEP", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCep.Focus();
                return;
            }

            btnConsultarCep.Enabled = false;
            UseWaitCursor = true;
            try
            {
                ResultadoConsultaCep endereco = await consultaCepServico
                    .ConsultarPorCepAsync(cep, CancellationToken.None);

                if (IsDisposed || endereco == null)
                {
                    if (endereco == null && !IsDisposed)
                        MessageBox.Show(this, "O CEP informado não foi encontrado na base do ViaCEP.",
                            "CEP não encontrado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                txtCep.Text = ExtrairDigitos(endereco.Cep ?? cep);
                cepOriginal = ExtrairDigitos(txtCep.Text);
                enderecoCepAtual = endereco;
            }
            catch (TaskCanceledException)
            {
                MessageBox.Show(this, "A consulta demorou mais que o esperado. Verifique sua conexão com a Internet.",
                    "Tempo de consulta excedido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (HttpRequestException erro)
            {
                MessageBox.Show(this, "Não foi possível acessar o serviço ViaCEP. Verifique sua conexão com a Internet.\r\n\r\nDetalhes: " + erro.Message,
                    "Falha na consulta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception erro)
            {
                MessageBox.Show(this, "Não foi possível consultar o CEP.\r\n\r\nDetalhes: " + erro.Message,
                    "Falha na consulta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (!IsDisposed)
                {
                    UseWaitCursor = false;
                    btnConsultarCep.Enabled = true;
                }
            }
        }

        // Evento de clique do botão de salvar, valida os campos e salva os dados do aluno
        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                Avisar("Informe o nome completo do aluno.", "Novo aluno", txtNome);
                return;
            }

            string cpf = ExtrairDigitos(txtCpf.Text);
            string telefone = ExtrairDigitos(txtTelefone.Text);
            string cep = ExtrairDigitos(txtCep.Text);
            bool maiorDeIdade = CalcularIdade(dtpNascimento.Value) >= 18;

            if (cpf.Length != 11)
            {
                Avisar("Informe os 11 números do CPF.", "CPF inválido", txtCpf);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtRg.Text) || txtRg.Text.Trim().Length > 14)
            {
                Avisar("Informe o RG (até 14 caracteres).", "RG inválido", txtRg);
                return;
            }
            if (cep.Length != 8)
            {
                Avisar("Informe os 8 números do CEP.", "CEP inválido", txtCep);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtNumero.Text) || txtNumero.Text.Trim().Length > 5)
            {
                Avisar("Informe o número do endereço (até 5 caracteres).", "Endereço", txtNumero);
                return;
            }
            if (telefone.Length > 0 && telefone.Length != 10 && telefone.Length != 11)
            {
                Avisar("Informe um telefone completo com DDD ou deixe o campo vazio.", "Telefone inválido", txtTelefone);
                return;
            }

            // Se o aluno for menor de idade, o campo de responsável é obrigatório
            FichaAluno ficha = alunoExistente ?? new FichaAluno { DataCadastro = DateTime.Today };
            ficha.Nome = txtNome.Text.Trim();
            ficha.DataNascimento = dtpNascimento.Value.Date;
            ficha.Telefone = txtTelefone.Text.Trim();
            ficha.Numero = txtNumero.Text.Trim();
            ficha.Cep = cep.Substring(0, 5) + "-" + cep.Substring(5);
            ficha.Complemento = txtComplemento.Text.Trim();

            // Com o CEP consultado, preenche os campos de endereço com os dados retornados
            if (enderecoCepAtual != null)
            {
                ficha.Logradouro = enderecoCepAtual.Logradouro;
                ficha.Bairro = enderecoCepAtual.Bairro;
                ficha.Cidade = enderecoCepAtual.Cidade;
            }

            // Se o CEP foi alterado, limpa os campos de endereço para evitar inconsistências
            else if (string.Equals(cep, cepOriginal, StringComparison.Ordinal))
            {
                ficha.Logradouro = string.Empty;
                ficha.Bairro = string.Empty;
                ficha.Cidade = string.Empty;
            }

            // Se o aluno for menor de idade, o campo de responsável é obrigatório
            ficha.Responsavel = maiorDeIdade ? string.Empty : txtResponsavel.Text.Trim();
            ficha.Cpf = txtCpf.Text.Trim();
            ficha.Rg = txtRg.Text.Trim();
            ficha.Email = txtEmail.Text.Trim();
            ficha.DiaVencimento = Convert.ToByte(nudDiaVencimento.Value);

            // Se o campo de responsável for obrigatório e estiver vazio, exibe um aviso
            string observacao = string.IsNullOrWhiteSpace(ficha.Responsavel)
                ? null
                : "Responsável: " + ficha.Responsavel.Trim();

            // Cria um objeto Aluno com os dados preenchidos no formulário
            Aluno aluno = new Aluno
            {
                IdAluno = ficha.IdAluno,
                Observacao = observacao,
                DataMatricula = ficha.DataCadastro == DateTime.MinValue ? DateTime.Today : ficha.DataCadastro,
                DiaVencimento = ficha.DiaVencimento,
                Situacao = "Ativo",
                Pessoa = new Pessoa
                {
                    Nome = ficha.Nome,
                    DataNascimento = ficha.DataNascimento,
                    IdEndereco = ficha.IdEndereco,
                    Cpf = cpf,
                    Rg = ficha.Rg,
                    Email = ficha.Email
                },
                Endereco = new Endereco
                {
                    Numero = ficha.Numero,
                    Cep = ficha.Cep,
                    Complemento = ficha.Complemento
                },
                Telefone = new Telefone { NumeroTelefone = telefone }
            };

            // Tenta salvar o aluno no banco de dados e trata possíveis erros
            try
            {
                alunoServico.Salvar(aluno);
                ficha.IdAluno = aluno.IdAluno;
                ficha.DataCadastro = ficha.DataCadastro == DateTime.MinValue ? DateTime.Today : ficha.DataCadastro;
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception erro)
            {
                MessageBox.Show(this,
                    "Não foi possível salvar o aluno no banco de dados.\r\n\r\n" + erro.Message,
                    "Falha no cadastro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Exibe uma mensagem de aviso para o usuário e foca no campo especificado com erro
        private void Avisar(string mensagem, string titulo, Control campo)
        {
            MessageBox.Show(this, mensagem, titulo, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            campo.Focus();
        }

        // Calcula a idade com base na data de nascimento fornecida
        private static int CalcularIdade(DateTime nascimento)
        {
            DateTime hoje = DateTime.Today;
            int idade = hoje.Year - nascimento.Year;
            if (nascimento.Date > hoje.AddYears(-idade)) idade--;
            return idade;
        }

        private static void ConfigurarFormatacaoProgressiva(TextBox campo, Func<string, string> formatador, int limite)
        {
            bool atualizando = false;
            campo.TextChanged += delegate
            {
                if (atualizando) return;
                int posicao = Math.Min(campo.SelectionStart, campo.Text.Length);
                int digitosAntes = ExtrairDigitos(campo.Text.Substring(0, posicao)).Length;
                string digitos = ExtrairDigitos(campo.Text);
                if (digitos.Length > limite) digitos = digitos.Substring(0, limite);
                string textoFormatado = formatador(digitos);
                if (campo.Text == textoFormatado) return;
                atualizando = true;
                try
                {
                    campo.Text = textoFormatado;
                    campo.SelectionStart = PosicaoAposDigitos(textoFormatado, digitosAntes);
                    campo.SelectionLength = 0;
                }
                finally { atualizando = false; }
            };
        }

        // Formata o número de telefone com DDD e traço
        private static string FormatarTelefone(string digitos)
        {
            if (digitos.Length <= 2) return digitos;
            string ddd = digitos.Substring(0, 2);
            string numero = digitos.Substring(2);
            string prefixo = "(" + ddd + ") ";
            int prefixoNumero = numero.StartsWith("9", StringComparison.Ordinal) ? 5 : 4;
            return numero.Length <= prefixoNumero
                ? prefixo + numero
                : prefixo + numero.Substring(0, prefixoNumero) + "-" + numero.Substring(prefixoNumero);
        }

        // Formata o CEP com traço
        private static string FormatarCep(string digitos)
        {
            return digitos.Length <= 5 ? digitos : digitos.Substring(0, 5) + "-" + digitos.Substring(5);
        }

        // Formata o CPF com pontos e traço
        private static string FormatarCpf(string digitos)
        {
            if (digitos.Length <= 3) return digitos;
            if (digitos.Length <= 6) return digitos.Substring(0, 3) + "." + digitos.Substring(3);
            if (digitos.Length <= 9) return digitos.Substring(0, 3) + "." + digitos.Substring(3, 3) + "." + digitos.Substring(6);
            return digitos.Substring(0, 3) + "." + digitos.Substring(3, 3) + "." + digitos.Substring(6, 3) + "-" + digitos.Substring(9);
        }

        // Extrai apenas os dígitos de uma string, removendo quaisquer caracteres não numéricos
        private static string ExtrairDigitos(string texto)
        {
            return Regex.Replace(texto ?? string.Empty, @"\D", string.Empty);
        }

        private static int PosicaoAposDigitos(string texto, int quantidade)
        {
            if (quantidade <= 0) return 0;
            int encontrados = 0;
            for (int i = 0; i < texto.Length; i++)
                if (char.IsDigit(texto[i]) && ++encontrados == quantidade) return i + 1;
            return texto.Length;
        }
    }
}
