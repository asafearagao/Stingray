using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Stingray.Entidades;
using Stingray.Servicos;

namespace Stingray {
    // Monta a tela de Alunos e a ficha individual do aluno
    partial class AlunosForm {
        // Estado dos botões de ação da grade.
        private int linhaAcaoSobMouseA = -1;
        private int botaoAcaoSobMouseA = -1;
        private int linhaBotaoPressionadoA = -1;
        private int botaoPressionadoA = -1;

        // Grade e rodapé

        private void ConstruirTela() {
            bool emDesignTime = ModoDesign.EstaEmModoDesign(this);
            lblTitulo.Text = "Alunos";

            ConfigurarCamposDeFiltro();
            ConfigurarBotaoLimpar();
            ConfigurarGradeExistente();
            AtualizarLayoutFiltrosAlunos();

            txtBusca.Text = string.Empty;
            txtBusca.ForeColor = VisualPadrao.TextoPrincipal;
            DefinirPlaceholder(txtBusca, "Digite o nome do aluno...");

            if (!emDesignTime) {
                btnNovoAluno.Click += AbrirDialogoNovoAluno;
                btnLimpar.Click += delegate { LimparFiltrosAlunos(); };

                txtBusca.TextChanged += delegate { AplicarFiltrosAlunos(); };
                cboFiltroTurma.SelectedIndexChanged += delegate { AplicarFiltrosAlunos(); };
                cboFiltroProfessor.SelectedIndexChanged += delegate { AplicarFiltrosAlunos(); };
                cboFiltroStatus.SelectedIndexChanged += delegate { AplicarFiltrosAlunos(); };
            }

            if (!emDesignTime)
                CarregarAlunos();

            PopularOpcoesFiltrosAlunos();

            if (!emDesignTime)
                AplicarFiltrosAlunos();
            else
                lblResumo.Text = "Mostrando " + dgvAlunos.Rows.Count.ToString() + " alunos";
        }

        private void AtualizarLayoutFiltrosAlunos() {
            layoutFiltrosAlunos.SuspendLayout();
            layoutFiltrosAlunos.Controls.Clear();
            layoutFiltrosAlunos.ColumnStyles.Clear();
            layoutFiltrosAlunos.RowStyles.Clear();

            layoutFiltrosAlunos.ColumnCount = 5;
            layoutFiltrosAlunos.RowCount = 2;
            layoutFiltrosAlunos.RowStyles.Add(new RowStyle(SizeType.Absolute, 18F));
            layoutFiltrosAlunos.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));

            layoutFiltrosAlunos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            layoutFiltrosAlunos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 23.33F));
            layoutFiltrosAlunos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 23.33F));
            layoutFiltrosAlunos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 23.34F));
            layoutFiltrosAlunos.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 104F));

            string[] filtros = { "Nome", "Turma", "Professor", "Status" };
            for (int i = 0; i < filtros.Length; i++) {
                Label titulo = ObterTituloFiltroAluno(filtros[i]);
                Control campo = ObterCampoFiltroAluno(filtros[i]);

                titulo.Dock = DockStyle.Fill;
                campo.Dock = DockStyle.Fill;
                layoutFiltrosAlunos.Controls.Add(titulo, i, 0);
                layoutFiltrosAlunos.Controls.Add(campo, i, 1);
            }

            btnLimpar.Dock = DockStyle.Fill;
            layoutFiltrosAlunos.Controls.Add(btnLimpar, 4, 1);
            layoutFiltrosAlunos.ResumeLayout(true);
        }

        private Label ObterTituloFiltroAluno(string chave) {
            if (chave == "Nome") return lblFiltroNome;
            if (chave == "Turma") return lblFiltroTurma;
            if (chave == "Professor") return lblFiltroProfessor;
            return lblFiltroStatus;
        }

        private Control ObterCampoFiltroAluno(string chave) {
            if (chave == "Nome") return pnlBuscaCampo;
            if (chave == "Turma") return pnlTurmaCampo;
            if (chave == "Professor") return pnlProfessorCampo;
            return pnlStatusCampo;
        }

        private void PopularOpcoesFiltrosAlunos() {
            PopularComboComValores(cboFiltroTurma, "Todas", "colTurma");
            PopularComboComValores(cboFiltroProfessor, "Todos", "colProfessor");
            PopularComboComValores(cboFiltroStatus, "Todos", "colStatus");
        }

        private void PopularComboComValores(ComboBox combo, string opcaoInicial, string nomeColuna) {
            combo.Items.Clear();
            combo.Items.Add(opcaoInicial);
            foreach (DataGridViewRow linha in dgvAlunos.Rows) {
                string valor = Convert.ToString(linha.Cells[nomeColuna].Value);
                if (string.IsNullOrWhiteSpace(valor) || EhValorSemAssociacao(valor))
                    continue;
                bool existe = false;
                foreach (object item in combo.Items) {
                    if (string.Equals(Convert.ToString(item), valor, StringComparison.CurrentCultureIgnoreCase)) {
                        existe = true;
                        break;
                    }
                }
                if (!existe)
                    combo.Items.Add(valor);
            }
            combo.SelectedIndex = 0;
        }

        private static bool EhValorSemAssociacao(string valor) {
            string texto = (valor ?? string.Empty).Trim();
            return texto.Length == 0 ||
                texto == "—" ||
                texto == "–" ||
                texto == "-" ||
                texto == "---" ||
                texto == "----";
        }

        private void ConfigurarCamposDeFiltro() {
            foreach (ComboBox combo in new ComboBox[] { cboFiltroTurma, cboFiltroProfessor, cboFiltroStatus }) {
                combo.DropDownStyle = ComboBoxStyle.DropDownList;
                combo.FlatStyle = FlatStyle.Flat;
                combo.DrawMode = DrawMode.OwnerDrawFixed;
                combo.ItemHeight = 18;
                combo.Font = new Font("Segoe UI", 8.5F, FontStyle.Regular, GraphicsUnit.Point);
                combo.ForeColor = VisualPadrao.TextoPrincipal;
                combo.BackColor = Color.White;
                combo.Margin = new Padding(0);
                combo.DrawItem += ComboFiltroAlunos_DrawItem;
            }

            ConfigurarSetaCombo(btnSetaFiltroTurma, cboFiltroTurma);
            ConfigurarSetaCombo(btnSetaFiltroProfessor, cboFiltroProfessor);
            ConfigurarSetaCombo(btnSetaFiltroStatus, cboFiltroStatus);

            txtBusca.BorderStyle = BorderStyle.None;
            txtBusca.AutoSize = false;
            txtBusca.Dock = DockStyle.Fill;
            txtBusca.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtBusca.BackColor = Color.White;
            txtBusca.Margin = new Padding(0);
        }

        private void ConfigurarSetaCombo(Button seta, ComboBox combo) {
            if (seta == null || combo == null)
                return;

            TableLayoutPanel layout = seta.Parent as TableLayoutPanel;
            Panel superficie = layout == null ? null : layout.Parent as Panel;
            if (layout == null || superficie == null)
                return;

            // O ComboBox ocupa a superfície inteira. O botão fica sobre a área
            // da seta nativa, para que só o chevron do Stingray fique visível.
            layout.Controls.Remove(combo);
            layout.Controls.Remove(seta);
            layout.Controls.Clear();
            layout.ColumnStyles.Clear();
            layout.ColumnCount = 1;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layout.Controls.Add(combo, 0, 0);
            combo.Dock = DockStyle.Fill;

            superficie.Controls.Add(seta);
            seta.Dock = DockStyle.None;
            seta.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            seta.Width = 26;
            seta.Height = superficie.ClientSize.Height;
            seta.Location = new Point(Math.Max(0, superficie.ClientSize.Width - seta.Width), 0);
            seta.AccessibleName = "Abrir opções";
            seta.AccessibleDescription = "Abre a lista de opções";
            seta.Visible = true;
            seta.Enabled = true;
            seta.TabStop = false;
            seta.Tag = combo;
            seta.Text = string.Empty;
            seta.Cursor = Cursors.Hand;
            seta.FlatStyle = FlatStyle.Flat;
            seta.FlatAppearance.BorderSize = 0;
            seta.BackColor = Color.White;
            seta.UseVisualStyleBackColor = false;
            seta.Paint -= DesenharSetaFiltroAluno;
            seta.Paint += DesenharSetaFiltroAluno;
            seta.MouseEnter += delegate { seta.BackColor = Color.FromArgb(239, 246, 255); seta.Invalidate(); };
            seta.MouseLeave += delegate { seta.BackColor = Color.White; seta.Invalidate(); };
            seta.Click -= AbrirComboFiltroAluno;
            seta.Click += AbrirComboFiltroAluno;

            superficie.SizeChanged += delegate {
                seta.SetBounds(Math.Max(0, superficie.ClientSize.Width - 26), 0, 26,
                    superficie.ClientSize.Height);
            };
            seta.BringToFront();
        }

        private void DesenharSetaFiltroAluno(object sender, PaintEventArgs e) {
            Button seta = sender as Button;
            if (seta == null || seta.ClientSize.Width < 8 || seta.ClientSize.Height < 8)
                return;

            bool sobre = seta.ClientRectangle.Contains(seta.PointToClient(Cursor.Position));
            Color cor = sobre ? Color.FromArgb(37, 99, 235) : Color.FromArgb(100, 116, 139);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (Pen separador = new Pen(Color.FromArgb(226, 232, 240)))
                e.Graphics.DrawLine(separador, 0, 1, 0, seta.ClientSize.Height - 2);
            float x = seta.ClientSize.Width / 2F;
            float y = seta.ClientSize.Height / 2F;
            using (Pen caneta = new Pen(cor, 1.6F)) {
                caneta.StartCap = LineCap.Round;
                caneta.EndCap = LineCap.Round;
                e.Graphics.DrawLines(caneta, new PointF[] {
                    new PointF(x - 3.5F, y - 1.5F),
                    new PointF(x, y + 2F),
                    new PointF(x + 3.5F, y - 1.5F)
                });
            }
        }

        private void AbrirComboFiltroAluno(object sender, EventArgs e) {
            Button seta = sender as Button;
            ComboBox combo = seta == null ? null : seta.Tag as ComboBox;
            if (combo == null || combo.IsDisposed)
                return;

            combo.Focus();
            combo.DroppedDown = true;
        }

        private void ComboFiltroAlunos_DrawItem(object sender, DrawItemEventArgs e) {
            ComboBox combo = sender as ComboBox;
            if (combo == null || e.Bounds.Width <= 0 || e.Bounds.Height <= 0) return;
            bool selecionado = combo.DroppedDown && e.Index >= 0 &&
                (e.State & DrawItemState.Selected) == DrawItemState.Selected;
            Color fundo = selecionado ? Color.FromArgb(239, 246, 255) : Color.White;
            using (Brush pincel = new SolidBrush(fundo)) e.Graphics.FillRectangle(pincel, e.Bounds);
            string valor = e.Index >= 0 && e.Index < combo.Items.Count
                ? Convert.ToString(combo.Items[e.Index])
                : combo.Text;
            TextRenderer.DrawText(e.Graphics, valor, combo.Font,
                Rectangle.Inflate(e.Bounds, -6, 0), VisualPadrao.TextoPrincipal,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);
        }

        private void ConfigurarBotaoLimpar() {
            btnLimpar.Text = "Limpar";
            btnLimpar.Size = new Size(92, 34);
            btnLimpar.CornerRadius = 5;
            btnLimpar.BackColor = Color.White;
            btnLimpar.ForeColor = VisualPadrao.TextoPrincipal;
            btnLimpar.FlatStyle = FlatStyle.Flat;
            btnLimpar.FlatAppearance.BorderSize = 0;
            btnLimpar.FlatAppearance.MouseOverBackColor = Color.FromArgb(254, 242, 242);
            btnLimpar.FlatAppearance.MouseDownBackColor = Color.FromArgb(254, 226, 226);
            btnLimpar.Cursor = Cursors.Hand;
            btnLimpar.UseVisualStyleBackColor = false;
            btnLimpar.MouseEnter += delegate {
                btnLimpar.ForeColor = Color.FromArgb(185, 28, 28);
                btnLimpar.FlatAppearance.BorderColor = Color.FromArgb(248, 113, 113);
                btnLimpar.BackColor = Color.FromArgb(254, 242, 242);
            };
            btnLimpar.MouseLeave += delegate {
                btnLimpar.ForeColor = VisualPadrao.TextoPrincipal;
                btnLimpar.FlatAppearance.BorderColor = Color.FromArgb(203, 213, 225);
                btnLimpar.BackColor = Color.White;
            };
            btnLimpar.MouseDown += delegate {
                btnLimpar.ForeColor = Color.FromArgb(153, 27, 27);
                btnLimpar.BackColor = Color.FromArgb(254, 226, 226);
            };
            btnLimpar.MouseUp += delegate {
                if (btnLimpar.ClientRectangle.Contains(btnLimpar.PointToClient(Cursor.Position))) {
                    btnLimpar.ForeColor = Color.FromArgb(185, 28, 28);
                    btnLimpar.BackColor = Color.FromArgb(254, 242, 242);
                }
            };
        }

        private void ConfigurarGradeExistente() {
            VisualPadrao.ConfigurarGrade(dgvAlunos);
            dgvAlunos.ColumnHeadersHeight = 38;
            dgvAlunos.RowTemplate.Height = 38;
            dgvAlunos.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvAlunos.ColumnHeadersDefaultCellStyle.Padding = new Padding(8, 0, 8, 0);
            dgvAlunos.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvAlunos.DefaultCellStyle.Padding = new Padding(8, 0, 8, 0);
            dgvAlunos.CellFormatting += Grade_CellFormatting;
            dgvAlunos.CellPainting += Grade_CellPainting;
            dgvAlunos.CellMouseMove += Grade_CellMouseMove;
            dgvAlunos.CellMouseLeave += Grade_CellMouseLeave;
            dgvAlunos.CellMouseClick += Grade_CellMouseClick;
            dgvAlunos.CellMouseDown += Grade_CellMouseDown;
            dgvAlunos.CellMouseUp += Grade_CellMouseUp;
            colAcoes.Width = 100;
            colAcoes.MinimumWidth = 100;
            colAcoes.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            colAcoes.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colAcoes.DefaultCellStyle.Padding = new Padding(0);
        }

        private void AbrirDialogoNovoAluno(object sender, EventArgs e) {
            AbrirDialogoAluno(null);
        }

        private void AbrirDialogoAluno(FichaAluno alunoExistente) {
            using (AlunoCadastroForm dialogo = new AlunoCadastroForm(alunoExistente)) {
                if (dialogo.ShowDialog(this) == DialogResult.OK) {
                    CarregarAlunos();
                    PopularOpcoesFiltrosAlunos();
                    AplicarFiltrosAlunos();
                }
            }
        }

        // Formulário de cadastro de aluno








        // Consulta o CEP sem bloquear a janela




        // Recarrega a grade com os registros do banco
        private void CarregarAlunos() {
            try {
                AlunoServico servico = new AlunoServico();
                List<Aluno> alunos = servico.ListarTodos();

                dgvAlunos.Rows.Clear();

                foreach (Aluno item in alunos) {
                    FichaAluno ficha = new FichaAluno {
                        IdAluno = item.IdAluno,
                        IdEndereco = item.Pessoa.IdEndereco,
                        IdMatricula = item.IdMatricula,
                        Nome = item.Pessoa.Nome,
                        DataNascimento = item.Pessoa.DataNascimento,
                        Telefone = item.Telefone == null ? string.Empty : item.Telefone.NumeroTelefone,
                        Numero = item.Endereco.Numero,
                        Cep = item.Endereco.Cep,
                        Complemento = item.Endereco.Complemento,
                        Responsavel = ExtrairNomeResponsavel(item.Observacao),
                        Cpf = item.Pessoa.Cpf,
                        Rg = item.Pessoa.Rg,
                        Email = item.Pessoa.Email,
                        DataCadastro = item.DataMatricula,
                        DiaVencimento = item.DiaVencimento,
                        Cidade = string.Empty
                    };

                    string turma = string.IsNullOrWhiteSpace(item.Modalidades) ? "—" : item.Modalidades;
                    string professor = string.IsNullOrWhiteSpace(item.Professores) ? "—" : item.Professores;
                    string status = item.Situacao == "Ativo" ? "Ativa"
                        : item.Situacao == "Inativo" ? "Inativa"
                        : item.Situacao == "Cancelado" ? "Cancelada"
                        : "Sem matrícula";

                    AdicionarLinhaAluno(ficha, turma, professor, "—", status);
                }
            }
            catch (Exception erro) {
                dgvAlunos.Rows.Clear();
                MessageBox.Show(this,
                    "Não foi possível carregar os alunos do banco de dados.\r\n\r\n" + erro.Message,
                    "Falha ao consultar alunos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static string ExtrairNomeResponsavel(string observacao) {
            const string prefixo = "Responsável:";
            if (string.IsNullOrWhiteSpace(observacao))
                return string.Empty;

            return observacao.StartsWith(prefixo, StringComparison.CurrentCultureIgnoreCase)
                ? observacao.Substring(prefixo.Length).Trim()
                : string.Empty;
        }

        // Tabela de alunos
        private DataGridView CriarGrade() {
            var g = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                RowHeadersVisible = false,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                EnableHeadersVisualStyles = false,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                GridColor = VisualPadrao.LinhaGrade,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = 38,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Margin = new Padding(0)
            };
            g.RowTemplate.Height = 38;

            // Cabeçalho com a mesma paleta da grade de Pagamentos
            g.ColumnHeadersDefaultCellStyle.BackColor = VisualPadrao.FundoCabecalhoGrade;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(55, 65, 81);
            g.ColumnHeadersDefaultCellStyle.SelectionBackColor = VisualPadrao.FundoCabecalhoGrade;
            g.ColumnHeadersDefaultCellStyle.SelectionForeColor = Color.FromArgb(55, 65, 81);
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            g.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            g.ColumnHeadersDefaultCellStyle.Padding = new Padding(8, 0, 8, 0);
            g.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True;

            // Células alinhadas e coloridas como em Pagamentos
            g.DefaultCellStyle.BackColor = Color.White;
            g.DefaultCellStyle.ForeColor = Color.FromArgb(55, 65, 81);
            g.DefaultCellStyle.SelectionBackColor = Color.White;
            g.DefaultCellStyle.SelectionForeColor = Color.FromArgb(55, 65, 81);
            g.DefaultCellStyle.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            g.DefaultCellStyle.Padding = new Padding(12, 0, 8, 0);
            g.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            g.AlternatingRowsDefaultCellStyle.BackColor = Color.White;
            g.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(55, 65, 81);
            g.AlternatingRowsDefaultCellStyle.SelectionBackColor = Color.White;
            g.AlternatingRowsDefaultCellStyle.SelectionForeColor = Color.FromArgb(55, 65, 81);
            g.ScrollBars = ScrollBars.Vertical;

            // Colunas principais da tabela de alunos
            g.Columns.Add("colData", "Data da Matrícula");
            g.Columns.Add("colAluno", "Aluno");
            g.Columns.Add("colTurma", "Turma");
            g.Columns.Add("colProfessor", "Professor");
            g.Columns.Add("colPlano", "Plano");
            g.Columns.Add("colStatus", "Status");

            // Mantém visualizar, editar e excluir na coluna Ações
            DataGridViewTextBoxColumn acoes = new DataGridViewTextBoxColumn
            {
                Name = "colAcoes", HeaderText = "Ações", ReadOnly = true, Width = 100, MinimumWidth = 100,
                AutoSizeMode = DataGridViewAutoSizeColumnMode.None, Resizable = DataGridViewTriState.False,
                SortMode = DataGridViewColumnSortMode.NotSortable
            };
            acoes.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            acoes.DefaultCellStyle.Padding = new Padding(0);
            acoes.DefaultCellStyle.SelectionBackColor = Color.White;
            acoes.DefaultCellStyle.SelectionForeColor = VisualPadrao.TextoPrincipal;
            g.Columns.Add(acoes);
            g.CellFormatting += Grade_CellFormatting;
            g.CellPainting += Grade_CellPainting;
            g.CellMouseMove += Grade_CellMouseMove;
            g.CellMouseLeave += Grade_CellMouseLeave;
            g.CellMouseClick += Grade_CellMouseClick;
            g.CellMouseDown += Grade_CellMouseDown;
            g.CellMouseUp += Grade_CellMouseUp;
            VisualPadrao.ConfigurarGrade(g);
            return g;
        }

        private Rectangle[] ObterRetangulosBotoesAcaoA(Rectangle celula) {
            const int tamanho = 24, espaco = 4;
            int largura = tamanho * 3 + espaco * 2;
            int x = celula.Left + Math.Max(2, (celula.Width - largura) / 2);
            int y = celula.Top + Math.Max(2, (celula.Height - tamanho) / 2);
            return new Rectangle[] { new Rectangle(x, y, tamanho, tamanho), new Rectangle(x + tamanho + espaco, y, tamanho, tamanho), new Rectangle(x + (tamanho + espaco) * 2, y, tamanho, tamanho) };
        }

        private int IndiceBotaoAcaoSobMouseA(int coluna, int linha) {
            if (coluna < 0 || linha < 0) return -1;
            Rectangle celula = dgvAlunos.GetCellDisplayRectangle(coluna, linha, false);
            Point mouse = dgvAlunos.PointToClient(Cursor.Position);
            Point local = new Point(mouse.X - celula.Left, mouse.Y - celula.Top);
            Rectangle[] botoes = ObterRetangulosBotoesAcaoA(new Rectangle(0, 0, celula.Width, celula.Height));
            for (int i = 0; i < botoes.Length; i++) if (botoes[i].Contains(local)) return i;
            return -1;
        }

        private void Grade_CellPainting(object sender, DataGridViewCellPaintingEventArgs e) {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            string nomeColuna = dgvAlunos.Columns[e.ColumnIndex].Name;
            if (nomeColuna == "colStatus") {
                using (Brush fundoCelula = new SolidBrush(Color.White)) e.Graphics.FillRectangle(fundoCelula, e.CellBounds);
                using (Pen linha = new Pen(Color.FromArgb(235, 239, 245)))
                    e.Graphics.DrawLine(linha, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right, e.CellBounds.Bottom - 1);
                string status = Convert.ToString(e.FormattedValue) ?? string.Empty;
                Color fundoSelo = Color.FromArgb(232, 247, 237);
                Color textoSelo = Color.FromArgb(38, 149, 74);
                int largura = 38;
                if (status == "Pausada") {
                    fundoSelo = Color.FromArgb(255, 244, 217);
                    textoSelo = Color.FromArgb(196, 122, 0);
                    largura = 54;
                } else if (status == "Cancelada") {
                    fundoSelo = Color.FromArgb(254, 228, 226);
                    textoSelo = Color.FromArgb(217, 45, 32);
                    largura = 58;
                }
                Rectangle selo = new Rectangle(e.CellBounds.Left + (e.CellBounds.Width - largura) / 2,
                    e.CellBounds.Top + (e.CellBounds.Height - 22) / 2, largura, 22);
                using (Brush brush = new SolidBrush(fundoSelo)) e.Graphics.FillRectangle(brush, selo);
                using (Font fonteStatus = new Font("Segoe UI", 7.5F))
                    TextRenderer.DrawText(e.Graphics, status, fonteStatus, selo, textoSelo,
                        TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                e.Handled = true;
                return;
            }
            if (nomeColuna != "colAcoes") return;
            e.PaintBackground(e.CellBounds, true);
            Rectangle[] botoes = ObterRetangulosBotoesAcaoA(e.CellBounds);
            string[] icones = { "\uE721", "\uE70F", "\uE74D" };
            for (int i = 0; i < botoes.Length; i++) {
                bool hover = e.RowIndex == linhaAcaoSobMouseA && botaoAcaoSobMouseA == i;
                bool pressionado = e.RowIndex == linhaBotaoPressionadoA && botaoPressionadoA == i;
                Color fundo;
                Color borda;
                Color icone;
                VisualPadrao.ObterCoresAcao(i == 2, i == 0, hover, pressionado, out fundo, out borda, out icone);
                using (Brush pincel = new SolidBrush(fundo))
                using (Pen caneta = new Pen(borda)) { e.Graphics.FillRectangle(pincel, botoes[i]); e.Graphics.DrawRectangle(caneta, botoes[i]); }
                using (Font fonte = new Font("Segoe MDL2 Assets", 10F))
                    TextRenderer.DrawText(e.Graphics, icones[i], fonte, botoes[i], icone, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            }
            e.Handled = true;
        }

        private void Grade_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e) {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || dgvAlunos.Columns[e.ColumnIndex].Name != "colAcoes") { LimparHoverAcoesA(); return; }
            int botao = IndiceBotaoAcaoSobMouseA(e.ColumnIndex, e.RowIndex);
            if (linhaAcaoSobMouseA == e.RowIndex && botaoAcaoSobMouseA == botao) return;
            LimparHoverAcoesA();
            linhaAcaoSobMouseA = e.RowIndex; botaoAcaoSobMouseA = botao;
            dgvAlunos.Cursor = botao >= 0 ? Cursors.Hand : Cursors.Default;
            dgvAlunos.InvalidateCell(e.ColumnIndex, e.RowIndex);
        }

        private void Grade_CellMouseLeave(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex == linhaAcaoSobMouseA && e.ColumnIndex >= 0 && dgvAlunos.Columns[e.ColumnIndex].Name == "colAcoes") LimparHoverAcoesA();
        }

        private void LimparHoverAcoesA() {
            int linha = linhaAcaoSobMouseA; linhaAcaoSobMouseA = -1; botaoAcaoSobMouseA = -1;
            dgvAlunos.Cursor = Cursors.Default;
            if (linha >= 0 && linha < dgvAlunos.Rows.Count && dgvAlunos.Columns.Contains("colAcoes")) dgvAlunos.InvalidateCell(dgvAlunos.Columns["colAcoes"].Index, linha);
        }

        private void Grade_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e) {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || dgvAlunos.Columns[e.ColumnIndex].Name != "colAcoes") return;
            int acao = IndiceBotaoAcaoSobMouseA(e.ColumnIndex, e.RowIndex);
            if (acao < 0) return;
            linhaBotaoPressionadoA = e.RowIndex; botaoPressionadoA = acao;
            dgvAlunos.InvalidateCell(e.ColumnIndex, e.RowIndex);
            dgvAlunos.Cursor = Cursors.Hand;
        }

        private void Grade_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e) {
            int linha = linhaBotaoPressionadoA;
            linhaBotaoPressionadoA = -1; botaoPressionadoA = -1;
            if (linha >= 0 && linha < dgvAlunos.Rows.Count && dgvAlunos.Columns.Contains("colAcoes"))
                dgvAlunos.InvalidateCell(dgvAlunos.Columns["colAcoes"].Index, linha);
        }

        private void Grade_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e) {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || dgvAlunos.Columns[e.ColumnIndex].Name != "colAcoes") return;
            int acao = IndiceBotaoAcaoSobMouseA(e.ColumnIndex, e.RowIndex);
            if (acao == 0) {
                FichaAluno aluno = dgvAlunos.Rows[e.RowIndex].Tag as FichaAluno;
                if (aluno != null) {
                    using (FichaAlunoForm ficha = new FichaAlunoForm(aluno))
                        ficha.ShowDialog(this);
                }
            }
            else if (acao == 1) EditarAluno(e.RowIndex);
            else if (acao == 2) ExcluirAluno(e.RowIndex);
        }

        private void EditarAluno(int indiceLinha) {
            if (indiceLinha < 0 || indiceLinha >= dgvAlunos.Rows.Count) return;
            FichaAluno aluno = dgvAlunos.Rows[indiceLinha].Tag as FichaAluno;
            if (aluno == null) return;
            AbrirDialogoAluno(aluno);
        }

        private void ExcluirAluno(int indiceLinha) {
            if (indiceLinha < 0 || indiceLinha >= dgvAlunos.Rows.Count) return;
            string nome = Convert.ToString(dgvAlunos.Rows[indiceLinha].Cells["colAluno"].Value) ?? "este aluno";
            if (MessageBox.Show(this, "Deseja realmente excluir definitivamente " + nome + "?\r\n\r\nTodos os dados, matrículas, mensalidades e registros de frequência desse aluno serão removidos. Esta ação não pode ser desfeita.", "Excluir aluno", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) {
                try {
                    FichaAluno aluno = dgvAlunos.Rows[indiceLinha].Tag as FichaAluno;
                    if (aluno == null || aluno.IdAluno <= 0)
                        return;

                    new AlunoServico().Excluir(aluno.IdAluno);
                    CarregarAlunos();
                    PopularOpcoesFiltrosAlunos();
                    AplicarFiltrosAlunos();
                }
                catch (Exception erro) {
                    MessageBox.Show(this, "Não foi possível excluir o aluno do banco de dados.\r\n\r\n" + erro.Message,
                        "Falha ao excluir", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // O status é desenhado como uma etiqueta colorida
        private void Grade_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e) {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || dgvAlunos.Columns[e.ColumnIndex].Name != "colStatus")
                return;
            e.CellStyle.BackColor = Color.White;
            e.CellStyle.ForeColor = Color.FromArgb(55, 65, 81);
            e.CellStyle.SelectionBackColor = Color.White;
            e.CellStyle.SelectionForeColor = Color.FromArgb(55, 65, 81);
            e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            e.CellStyle.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
        }

        // Rodapé da lista de alunos
        private Control CriarRodape() {
            var rodape = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                ColumnCount = 2,
                BackColor = Color.White,
                Padding = new Padding(0, 8, 0, 0),
                Margin = new Padding(0)
            };
            rodape.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            lblResumo = new Label
            {
                Text = "Mostrando 0 alunos",
                AutoSize = true,
                ForeColor = VisualPadrao.TextoSecundario,
                Anchor = AnchorStyles.Left
            };
            rodape.Controls.Add(lblResumo, 0, 0);

            return rodape;
        }

        // Métodos auxiliares de layout

        // Cria um cartão com borda para cadastro e filtros
        private TableLayoutPanel CriarCard(int colunas) {
            var card = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                ColumnCount = colunas,
                BackColor = Color.White,
                BorderStyle = BorderStyle.None,
                Padding = new Padding(16, 10, 16, 4),
                Margin = new Padding(12, 0, 12, 12)
            };
            card.Paint += delegate(object sender, PaintEventArgs e) {
                VisualPadrao.DesenharBordaCartao(e.Graphics, card.ClientRectangle);
            };
            return card;
        }

        // Coloca "label em cima + controle embaixo" na posição pedida
        // "colunasOcupadas" permite um campo ocupar mais de uma coluna (ex.: Nome do aluno)
        private void AdicionarCampo(TableLayoutPanel card, string texto, Control controle,
                                    int coluna, int linhaDoLabel, int colunasOcupadas = 1) {
            var lbl = new Label
            {
                Text = texto,
                AutoSize = true,
                Font = new Font("Segoe UI", 8F, FontStyle.Regular, GraphicsUnit.Point),
                ForeColor = Color.FromArgb(55, 65, 81),
                Margin = new Padding(0, 0, 0, 4)
            };
            controle.Font = new Font("Segoe UI", 10F);
            controle.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            controle.Margin = new Padding(0, 0, 16, 10);

            card.Controls.Add(lbl, coluna, linhaDoLabel);
            card.Controls.Add(controle, coluna, linhaDoLabel + 1);

            if (colunasOcupadas > 1) {
                card.SetColumnSpan(lbl, colunasOcupadas);
                card.SetColumnSpan(controle, colunasOcupadas);
            }
        }

        // Aplica uma máscara aos campos numéricos
        private MaskedTextBox CriarMascara(string mascara) {
            return new MaskedTextBox
            {
                Mask = mascara,
                PromptChar = '_'
            };
        }

        private Button CriarBotao(string texto, int largura, Color fundo, Color corTexto, Color borda) {
            var b = new Button
            {
                Text = texto,
                Size = new Size(largura, 34),
                FlatStyle = FlatStyle.Flat,
                BackColor = fundo,
                ForeColor = corTexto,
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false
            };
            b.FlatAppearance.BorderColor = borda;
            b.FlatAppearance.BorderSize = 1;
            return b;
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);
        private const int EM_SETCUEBANNER = 0x1501;

        private static void DefinirPlaceholder(TextBox txt, string texto) {
            if (txt.IsHandleCreated)
                SendMessage(txt.Handle, EM_SETCUEBANNER, (IntPtr)1, texto);
            else
                txt.HandleCreated += (s, e) => SendMessage(txt.Handle, EM_SETCUEBANNER, (IntPtr)1, texto);
        }

        private void LimparFiltrosAlunos() {
            // Limpar remove os valores informados, mas mantém os campos visíveis.
            txtBusca.Clear();
            if (cboFiltroTurma.Items.Count > 0) cboFiltroTurma.SelectedIndex = 0;
            if (cboFiltroProfessor.Items.Count > 0) cboFiltroProfessor.SelectedIndex = 0;
            if (cboFiltroStatus.Items.Count > 0) cboFiltroStatus.SelectedIndex = 0;
            AplicarFiltrosAlunos();
        }

        private void AplicarFiltrosAlunos() {
            if (dgvAlunos == null || dgvAlunos.IsDisposed) return;
            string busca = txtBusca != null ? txtBusca.Text.Trim() : string.Empty;
            string turma = cboFiltroTurma.SelectedIndex > 0 ? Convert.ToString(cboFiltroTurma.SelectedItem) : string.Empty;
            string professor = cboFiltroProfessor.SelectedIndex > 0 ? Convert.ToString(cboFiltroProfessor.SelectedItem) : string.Empty;
            string status = cboFiltroStatus.SelectedIndex > 0 ? Convert.ToString(cboFiltroStatus.SelectedItem) : string.Empty;
            int exibidos = 0;
            foreach (DataGridViewRow linha in dgvAlunos.Rows) {
                FichaAluno aluno = linha.Tag as FichaAluno;
                string nome = Convert.ToString(linha.Cells["colAluno"].Value) ?? string.Empty;
                bool visivel = busca.Length == 0 || nome.IndexOf(busca, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                    (aluno != null && aluno.Cpf.IndexOf(busca, StringComparison.CurrentCultureIgnoreCase) >= 0);
                if (visivel && turma.Length > 0) visivel = string.Equals(Convert.ToString(linha.Cells["colTurma"].Value), turma, StringComparison.CurrentCultureIgnoreCase);
                if (visivel && professor.Length > 0) visivel = string.Equals(Convert.ToString(linha.Cells["colProfessor"].Value), professor, StringComparison.CurrentCultureIgnoreCase);
                if (visivel && status.Length > 0) visivel = string.Equals(Convert.ToString(linha.Cells["colStatus"].Value), status, StringComparison.CurrentCultureIgnoreCase);
                if (!visivel && dgvAlunos.CurrentCell != null && dgvAlunos.CurrentCell.RowIndex == linha.Index) dgvAlunos.CurrentCell = null;
                linha.Visible = visivel;
                if (visivel) exibidos++;
            }
            if (lblResumo != null) lblResumo.Text = "Mostrando " + exibidos.ToString() + " de " + dgvAlunos.Rows.Count.ToString() + " alunos";
        }

        // Adiciona uma linha na grade e guarda a ficha completa do aluno dentro dela (Tag)
        private void AdicionarLinhaAluno(FichaAluno aluno, string turma, string professor, string plano, string status) {
            string dataMatricula = aluno.DataCadastro == DateTime.MinValue
                ? "—"
                : aluno.DataCadastro.ToString("dd/MM/yyyy");
            int indice = dgvAlunos.Rows.Add(dataMatricula, aluno.Nome,
                                                turma, professor, plano, status);
            dgvAlunos.Rows[indice].Tag = aluno;
        }

    }

    // Dados exibidos na ficha do aluno
    public class FichaAluno {
        public int IdAluno { get; set; }
        public int IdEndereco { get; set; }
        public int IdMatricula { get; set; }
        public byte DiaVencimento { get; set; }
        public string Logradouro { get; set; }
        public string Bairro { get; set; }
        public string Complemento { get; set; }
        public string Nome { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Telefone { get; set; }
        public string Numero { get; set; }
        public string Cep { get; set; }
        public string Cidade { get; set; }
        public string Responsavel { get; set; }
        public string Cpf { get; set; }
        public string Rg { get; set; }
        public string Email { get; set; }
        public DateTime DataCadastro { get; set; }
    }

}
