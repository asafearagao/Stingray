using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Stingray.Entidades;
using Stingray.Servicos;
using Stingray.DadosTela;

namespace Stingray {
    [DesignerCategory("Form")]
    public partial class DashboardForm : Form {
        private Button paginaSelecionada;
        private readonly Dictionary<Button, Form> paginasCriadas = new Dictionary<Button, Form>();
        private readonly Usuario usuarioLogado;
        private readonly DashboardServico dashboardServico = new DashboardServico();

        public DashboardForm() : this(null) {
        }

        // Construtor que recebe o usuário logado para exibir seu nome e controlar permissões
        public DashboardForm(Usuario usuarioLogado) {
            this.usuarioLogado = usuarioLogado;
            InitializeComponent();
            ConfigurarBordasDosCartoes();
            bool emDesignTime = ModoDesign.EstaEmModoDesign(this);
            if (emDesignTime)
                return;

            WindowState = FormWindowState.Maximized;
            ConfigurarEventosNavegacao();
            AjustarLarguraNavegacao();
            SelecionarPagina(btnDashboard);
            AtualizarIndicadoresDashboard();
        }

        private void DashboardContentPanel_Paint(object sender, PaintEventArgs e) {
            VisualPadrao.DesenharBordaCartao(e.Graphics, dashboardContentPanel.ClientRectangle);
        }

        private void DashAulasTabela_CellPaint(object sender, TableLayoutCellPaintEventArgs e) {
            if (e.Row < 3) {
                using (Pen linha = new Pen(Color.FromArgb(229, 234, 241), 1F))
                    e.Graphics.DrawLine(linha, e.CellBounds.Left + 1, e.CellBounds.Bottom - 1, e.CellBounds.Right - 1, e.CellBounds.Bottom - 1);
            }
        }

        // Configura as bordas arredondadas e a cor de fundo dos cartões do Dashboard
        private void ConfigurarBordasDosCartoes() {
            Control[] cartoes = {
                dashCardAlunos, dashCardProfessores, dashCardTurmas,
                dashCardAulas, dashCardPagamentos
            };

            foreach (Control cartao in cartoes) {
                if (cartao == null)
                    continue;

                Panel painel = cartao as Panel;
                if (painel == null)
                    continue;

                painel.BorderStyle = BorderStyle.None;
                painel.BackColor = Color.White;
                if (painel == dashCardAlunos || painel == dashCardProfessores || painel == dashCardTurmas)
                    painel.Padding = new Padding(2);
                painel.Paint -= DashboardCard_Paint;
                painel.Paint += DashboardCard_Paint;
            }
        }

        // Desenha a borda arredondada de um cartão do Dashboard
        private void DashboardCard_Paint(object sender, PaintEventArgs e) {
            Control cartao = sender as Control;
            if (cartao != null)
                VisualPadrao.DesenharBordaCartao(e.Graphics, cartao.ClientRectangle);
        }

        // Configura os eventos de clique e hover dos botões de navegação do menu lateral
        private void ConfigurarEventosNavegacao() {
            foreach (Button botao in BotoesNavegacao()) {
                RoundedButton visual = botao as RoundedButton;
                if (visual != null)
                    visual.CornerRadius = 7;
                botao.Height = 40;
                botao.Font = new Font("Segoe UI Semibold", 9.25F, FontStyle.Regular, GraphicsUnit.Point);
                botao.Padding = new Padding(12, 0, 4, 0);
                botao.TextAlign = ContentAlignment.MiddleLeft;
                botao.FlatAppearance.BorderSize = 0;
                botao.Click += Navegacao_Click;
                botao.MouseEnter += BotaoMenu_MouseEnter;
                botao.MouseLeave += BotaoMenu_MouseLeave;
                botao.SizeChanged += delegate { AjustarLarguraNavegacao(); };
            }

            RoundedButton sairArredondado = btnSair as RoundedButton;
            if (sairArredondado != null)
                sairArredondado.CornerRadius = 7;
            btnSair.Height = 40;
            btnSair.Font = new Font("Segoe UI Semibold", 9.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnSair.Padding = new Padding(12, 0, 4, 0);
            btnSair.FlatAppearance.BorderSize = 0;
            btnSair.Click += delegate { Close(); };
            btnSair.MouseEnter += delegate {
                btnSair.BackColor = VisualPadrao.AzulClaro;
                btnSair.ForeColor = VisualPadrao.Azul;
                btnSair.FlatAppearance.BorderColor = Color.FromArgb(185, 208, 242);
                btnSair.Invalidate();
            };
            btnSair.MouseLeave += delegate {
                btnSair.BackColor = Color.White;
                btnSair.ForeColor = VisualPadrao.TextoPrincipal;
                btnSair.FlatAppearance.BorderColor = Color.FromArgb(229, 231, 235);
                btnSair.Invalidate();
            };
            navPanel.SizeChanged += delegate { AjustarLarguraNavegacao(); };
            footerPanel.SizeChanged += delegate {
                btnSair.Width = Math.Max(100, footerPanel.ClientSize.Width - footerPanel.Padding.Left - footerPanel.Padding.Right);
                btnSair.Left = footerPanel.Padding.Left;
                btnSair.Top = Math.Max(0, footerPanel.ClientSize.Height - footerPanel.Padding.Bottom - btnSair.Height);
            };
        }

        // Retorna os botões de navegação do menu lateral
        private Button[] BotoesNavegacao() {
            return new Button[] {
                btnDashboard, btnProfessores, btnTurmas,
                btnAlunos, btnPagamentos, btnPresenca, btnRelatorios, btnConfiguracoes
            };
        }

        // Ajusta a largura dos botões de navegação para preencher o painel lateral
        private void AjustarLarguraNavegacao() {
            if (navPanel == null)
                return;
            int largura = Math.Max(120, navPanel.ClientSize.Width - navPanel.Padding.Left - navPanel.Padding.Right - 2);
            foreach (Button botao in BotoesNavegacao())
                botao.Width = largura;
        }

        // Trata o clique em um botão de navegação e exibe a página correspondente
        private void Navegacao_Click(object sender, EventArgs e) {
            Button botao = sender as Button;
            if (botao != null)
                MostrarPagina(botao);
        }

        // Exibe a página correspondente ao botão clicado, ocultando as demais páginas
        private void MostrarPagina(Button botao) {
            if (botao == btnDashboard) {
                foreach (Control paginaVisivel in contentHost.Controls) {
                    if (paginaVisivel == dashboardPagePanel)
                        continue;

                    PagamentosForm pagamentos = paginaVisivel as PagamentosForm;
                    if (pagamentos != null)
                        pagamentos.FecharSeletores();
                    PresencaForm presenca = paginaVisivel as PresencaForm;
                    if (presenca != null)
                        presenca.FecharSeletores();
                    paginaVisivel.Visible = false;
                }

                dashboardPagePanel.Visible = true;
                dashboardPagePanel.BringToFront();
                SelecionarPagina(btnDashboard);
                AtualizarIndicadoresDashboard();
                return;
            }

            // Para os demais botões, obtém a página correspondente e exibe-a
            Form pagina = ObterPagina(botao);
            if (pagina == null)
                return;

            // Oculta todas as páginas, exceto a selecionada
            foreach (Control controle in contentHost.Controls) {
                if (controle != pagina) {
                    PagamentosForm pagamentos = controle as PagamentosForm;
                    if (pagamentos != null)
                        pagamentos.FecharSeletores();
                    PresencaForm presenca = controle as PresencaForm;
                    if (presenca != null)
                        presenca.FecharSeletores();
                    controle.Visible = false;
                }
            }

            if (pagina.Parent != contentHost) {
                pagina.TopLevel = false;
                pagina.FormBorderStyle = FormBorderStyle.None;
                pagina.ControlBox = false;
                pagina.Dock = DockStyle.Fill;
                pagina.Visible = false;
                contentHost.Controls.Add(pagina);
            }

            // Exibe a página selecionada
            pagina.Dock = DockStyle.Fill;
            if (!pagina.Visible)
                pagina.Show();
            pagina.Visible = true;
            pagina.BringToFront();
            SelecionarPagina(botao);
        }

        private void AtualizarIndicadoresDashboard() {
            try {
                ResumoDashboard resumo = dashboardServico.ObterResumo();
                dashValorAlunos.Text = resumo.TotalAlunos.ToString();
                dashValorProfessores.Text = resumo.TotalProfessores.ToString();
                dashValorTurmas.Text = resumo.TotalTurmas.ToString();
            }
            catch {
                // Mantém o painel utilizável mesmo quando o banco estiver indisponível
                dashValorAlunos.Text = "—";
                dashValorProfessores.Text = "—";
                dashValorTurmas.Text = "—";
            }

            AtualizarProximasAulas();
        }

        private void AtualizarProximasAulas()
        {
            // Atualiza a lista de próximas aulas no Dashboard, exibindo até 4 aulas
            Label[] horarios = { dashAulaHora1, dashAulaHora2, dashAulaHora3, dashAulaHora4 };
            Label[] modalidades = { dashAulaNome1, dashAulaNome2, dashAulaNome3, dashAulaNome4 };
            Label[] professores = { dashAulaProfessor1, dashAulaProfessor2, dashAulaProfessor3, dashAulaProfessor4 };

            try
            {
                List<ProximaAulaDashboard> aulas = dashboardServico.ObterProximasAulas(4);

                // Preenche os campos das próximas aulas, ou exibe uma mensagem caso não haja aulas
                for (int i = 0; i < horarios.Length; i++)
                {
                    bool existeAula = i < aulas.Count;
                    horarios[i].Text = existeAula ? aulas[i].DataHora.ToString("HH:mm") : string.Empty;
                    modalidades[i].Text = existeAula
                        ? aulas[i].Modalidade + " · " + aulas[i].DataHora.ToString("dd/MM")
                        : string.Empty;
                    professores[i].Text = existeAula
                        ? "Professor: " + aulas[i].NomeProfessor
                        : string.Empty;
                }

                if (aulas.Count == 0)
                {
                    modalidades[0].Text = "Nenhuma próxima aula encontrada.";
                    professores[0].Text = string.Empty;
                }
            }
            catch
            {
                horarios[0].Text = string.Empty;
                modalidades[0].Text = "Não foi possível carregar as próximas aulas.";
                professores[0].Text = string.Empty;

                // Limpa os campos das próximas aulas restantes
                for (int i = 1; i < horarios.Length; i++)
                {
                    horarios[i].Text = string.Empty;
                    modalidades[i].Text = string.Empty;
                    professores[i].Text = string.Empty;
                }
            }
        }

        // Retorna a página correspondente ao botão de navegação, criando-a se necessário
        private Form ObterPagina(Button botao) {
            Form pagina;
            if (paginasCriadas.TryGetValue(botao, out pagina))
                return pagina;

            if (botao == btnPagamentos) pagina = new PagamentosForm();
            else if (botao == btnProfessores) pagina = new ProfessoresForm();
            else if (botao == btnTurmas) pagina = new TurmasForm();
            else if (botao == btnAlunos) pagina = new AlunosForm();
            else if (botao == btnPresenca) pagina = new PresencaForm();
            else if (botao == btnRelatorios) pagina = new RelatoriosForm();
            else if (botao == btnConfiguracoes) pagina = new ConfiguracoesForm(usuarioLogado);
            else return null;

            paginasCriadas.Add(botao, pagina);
            return pagina;
        }

        private void SelecionarPagina(Button botao) {
            paginaSelecionada = botao;
            foreach (Button item in BotoesNavegacao()) {
                // Atualiza a aparência do botão selecionado e dos demais botões
                bool selecionado = item == botao;
                item.BackColor = selecionado
                    ? VisualPadrao.AzulClaro
                    : Color.White;
                item.ForeColor = selecionado
                    ? VisualPadrao.Azul
                    : VisualPadrao.TextoPrincipal;
                RoundedButton botaoArredondado = item as RoundedButton;
                if (botaoArredondado != null)
                    botaoArredondado.ShowLeftIndicator = selecionado;
                item.FlatAppearance.BorderColor = selecionado
                    ? Color.FromArgb(185, 208, 242)
                    : Color.FromArgb(229, 231, 235);
                item.Invalidate();
            }
        }

        // Altera a aparência do botão de navegação quando o mouse entra ou sai da área do botão
        private void BotaoMenu_MouseEnter(object sender, EventArgs e) {
            Button botao = sender as Button;
            if (botao == null || botao == paginaSelecionada)
                return;
            botao.BackColor = VisualPadrao.AzulClaro;
            botao.ForeColor = VisualPadrao.Azul;
            botao.FlatAppearance.BorderColor = Color.FromArgb(185, 208, 242);
            botao.Invalidate();
        }

        private void BotaoMenu_MouseLeave(object sender, EventArgs e) {
            Button botao = sender as Button;
            if (botao == null || botao == paginaSelecionada)
                return;
            botao.BackColor = Color.White;
            botao.ForeColor = VisualPadrao.TextoPrincipal;
            botao.FlatAppearance.BorderColor = Color.FromArgb(229, 231, 235);
            botao.Invalidate();
        }
    }
}
