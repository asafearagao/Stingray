using System;
using System.Globalization;
using System.Threading.Tasks;
using System.Windows.Forms;
using Stingray.DadosTela;
using Stingray.Servicos;

namespace Stingray
{
    [System.ComponentModel.DesignerCategory("Form")]
    public partial class FichaAlunoForm : Form
    {
        private static readonly CultureInfo CulturaPtBr = new CultureInfo("pt-BR");
        private readonly FichaAluno aluno;
        private readonly ConsultaCepServico consultaCepServico = new ConsultaCepServico();

        public FichaAlunoForm()
        {
            InitializeComponent();
        }

        // Construtor que recebe um aluno existente para exibir seus dados
        public FichaAlunoForm(FichaAluno aluno) : this()
        {
            if (aluno == null)
                throw new ArgumentNullException(nameof(aluno));

            this.aluno = aluno;
            PreencherDados();
            Shown += async delegate { await CarregarEnderecoViaCepAsync(); };
            btnFechar.Click += delegate { Close(); };
            AcceptButton = btnFechar;
            CancelButton = btnFechar;
        }

        // Preenche os campos do formulário com os dados do aluno
        private void PreencherDados()
        {
            lblNomeValor.Text = ValorOuTraco(aluno.Nome);
            lblNascimentoValor.Text = aluno.DataNascimento.ToString("dd/MM/yyyy");
            lblTelefoneValor.Text = ValorOuTraco(aluno.Telefone);
            lblNumeroValor.Text = ValorOuTraco(aluno.Numero);
            lblCepValor.Text = ValorOuTraco(aluno.Cep);
            lblComplementoValor.Text = ValorOuTraco(aluno.Complemento);
            lblRuaValor.Text = ValorOuTraco(aluno.Logradouro);
            lblBairroValor.Text = ValorOuTraco(aluno.Bairro);
            lblCidadeValor.Text = ValorOuTraco(aluno.Cidade);
            lblResponsavelValor.Text = ValorOuTraco(aluno.Responsavel);
            lblCpfValor.Text = ValorOuTraco(aluno.Cpf);
            lblRgValor.Text = ValorOuTraco(aluno.Rg);
            lblEmailValor.Text = ValorOuTraco(aluno.Email);
            lblDataMatricula.Text = aluno.DataCadastro == DateTime.MinValue
                ? "Matrícula ainda não registrada."
                : "Campinas, " + aluno.DataCadastro.ToString("d 'de' MMMM 'de' yyyy", CulturaPtBr) + ".";
        }

        // Consulta o endereço do aluno pelo CEP usando o serviço ViaCEP
        private async Task CarregarEnderecoViaCepAsync()
        {
            if (string.IsNullOrWhiteSpace(aluno.Cep))
                return;

            try
            {
                ResultadoConsultaCep endereco = await consultaCepServico.ConsultarPorCepAsync(aluno.Cep);
                if (IsDisposed || endereco == null)
                    return;

                lblRuaValor.Text = ValorOuTraco(endereco.Logradouro);
                lblBairroValor.Text = ValorOuTraco(endereco.Bairro);
                lblCidadeValor.Text = ValorOuTraco(endereco.Cidade);
            }
            catch
            {
                // A ficha permanece disponível mesmo quando o serviço externo está indisponível.
            }
        }

        // Retorna um valor ou um traço se o valor for nulo ou vazio
        private static string ValorOuTraco(string valor)
        {
            return string.IsNullOrWhiteSpace(valor) ? "—" : valor;
        }
    }
}
