using System;
using System.Collections.Generic;  // Listas
using MySqlConnector;              // Conexão com o MySQL
using Stingray.BancoDeDados;
using Stingray.Entidades;

namespace Stingray.Repositorios
{
    // Consulta e cadastro de alunos

    // Mantém as alterações dos dados relacionados na mesma transação
    public class AlunoRepositorio : RepositorioMySqlBase
    {
        private readonly PessoaRepositorio pessoaRepositorio = new PessoaRepositorio();

        // Consulta os dados de cadastro dos alunos
        private const string SqlListarAlunos = @"
            SELECT a.id_aluno, a.observacao, p.nome, p.data_nascimento, p.cpf, p.rg,
                   p.email, p.id_endereco, e.numero, e.cep, e.complemento,
                   tel.numero_telefone AS telefone,
                   CASE WHEN m.situacao = 'Ativo' THEN m.id_matricula ELSE NULL END AS id_matricula,
                   m.data_matricula, m.dia_vencimento, m.situacao,
                   vinculos.modalidades, vinculos.professores
            FROM aluno a
            INNER JOIN pessoa p ON p.id_pessoa = a.id_aluno
            INNER JOIN endereco e ON e.id_endereco = p.id_endereco
            LEFT JOIN (
                SELECT matricula_atual.* FROM matricula matricula_atual
                INNER JOIN (
                    SELECT id_aluno, MAX(id_matricula) AS id_matricula
                    FROM matricula GROUP BY id_aluno
                ) ultima ON ultima.id_matricula = matricula_atual.id_matricula
            ) m ON m.id_aluno = a.id_aluno
            LEFT JOIN (
                SELECT id_pessoa, MIN(id_telefone) AS id_telefone
                FROM telefone GROUP BY id_pessoa
            ) telefone_principal ON telefone_principal.id_pessoa = p.id_pessoa
            LEFT JOIN telefone tel ON tel.id_telefone = telefone_principal.id_telefone
            LEFT JOIN (
                SELECT m.id_aluno,
                       GROUP_CONCAT(DISTINCT t.modalidade ORDER BY t.modalidade SEPARATOR ', ') AS modalidades,
                       GROUP_CONCAT(DISTINCT professor.nome ORDER BY professor.nome SEPARATOR ', ') AS professores
                FROM matricula m
                INNER JOIN turma_matricula tm ON tm.id_matricula = m.id_matricula
                INNER JOIN turma t ON t.id_turma = tm.id_turma
                INNER JOIN professor pr ON pr.id_professor = t.id_professor
                INNER JOIN pessoa professor ON professor.id_pessoa = pr.id_professor
                WHERE m.situacao = 'Ativo'
                GROUP BY m.id_aluno
            ) vinculos ON vinculos.id_aluno = a.id_aluno
            ORDER BY p.nome;";

        // Lista os alunos com seus dados de cadastro
        public List<Aluno> ListarTodos()
        {
            return ConsultarLista(SqlListarAlunos, null, MapearAluno);
        }

        public int Inserir(Aluno aluno) // Caso falhe, nenhuma parte do cadastro é mantida
        {
            if (aluno == null) // Verifica se o aluno não é nulo
                throw new ArgumentNullException(nameof(aluno));

            return ExecutarTransacao<int>(delegate (MySqlConnection conexao, MySqlTransaction transacao)
            {
                int idEndereco = pessoaRepositorio.InserirEndereco(conexao, transacao, aluno.Endereco);
                int idAluno = pessoaRepositorio.InserirPessoa(conexao, transacao, aluno.Pessoa, idEndereco);

                InserirRegistroAluno(conexao, transacao, idAluno, aluno.Observacao);
                InserirMatriculaInicial(conexao, transacao, idAluno, aluno.DiaVencimento);
                pessoaRepositorio.SincronizarTelefone(conexao, transacao, idAluno, aluno.Telefone);

                return idAluno;
            });
        }

        public void Atualizar(Aluno aluno)
        {
            if (aluno == null) // Verifica se o aluno não é nulo
                throw new ArgumentNullException(nameof(aluno));

            ExecutarTransacao(delegate (MySqlConnection conexao, MySqlTransaction transacao)
            {
                // Verifica se o aluno existe no banco de dados antes de atualizar
                if (!AlunoExiste(conexao, transacao, aluno.IdAluno))
                    throw new InvalidOperationException("O aluno não foi encontrado no banco de dados.");

                int idEndereco = pessoaRepositorio.ObterIdEndereco(conexao, transacao, aluno.IdAluno);
                pessoaRepositorio.AtualizarEndereco(conexao, transacao, aluno.Endereco, idEndereco);
                pessoaRepositorio.AtualizarPessoa(conexao, transacao, aluno.Pessoa, aluno.IdAluno);
                AtualizarObservacao(conexao, transacao, aluno.IdAluno, aluno.Observacao);
                AtualizarMatriculaAtiva(conexao, transacao, aluno);
                pessoaRepositorio.SincronizarTelefone(conexao, transacao, aluno.IdAluno, aluno.Telefone);
            });
        }

        // Exclui o aluno e os dados relacionados (responsável, frequência, mensalidade, pessoa)
        public void Excluir(int idAluno)
        {
            if (idAluno <= 0) // Valida o ID do aluno
                throw new ArgumentException("Informe um aluno válido.", nameof(idAluno));

            // Delete em cascata
            ExecutarTransacao(delegate (MySqlConnection conexao, MySqlTransaction transacao)
            {
                int idEndereco = pessoaRepositorio.ObterIdEndereco(conexao, transacao, idAluno);

                ExecutarExclusaoAluno(conexao, transacao,
                    "DELETE FROM aluno_responsavel WHERE id_aluno = @id OR id_responsavel = @id;", idAluno);
                ExecutarExclusaoAluno(conexao, transacao,
                    "DELETE f FROM frequencia f INNER JOIN matricula m ON m.id_matricula = f.id_matricula WHERE m.id_aluno = @id;", idAluno);
                ExecutarExclusaoAluno(conexao, transacao,
                    "DELETE FROM mensalidade WHERE id_matricula IN (SELECT id_matricula FROM matricula WHERE id_aluno = @id);", idAluno);
                ExecutarExclusaoAluno(conexao, transacao,
                    "DELETE FROM turma_matricula WHERE id_matricula IN (SELECT id_matricula FROM matricula WHERE id_aluno = @id);", idAluno);
                ExecutarExclusaoAluno(conexao, transacao,
                    "DELETE FROM matricula WHERE id_aluno = @id;", idAluno);
                ExecutarExclusaoAluno(conexao, transacao,
                    "DELETE FROM responsavel WHERE id_responsavel = @id;", idAluno);
                ExecutarExclusaoAluno(conexao, transacao,
                    "DELETE FROM aluno WHERE id_aluno = @id;", idAluno);
                pessoaRepositorio.ExcluirTelefones(conexao, transacao, idAluno);
                pessoaRepositorio.ExcluirPessoa(conexao, transacao, idAluno);
                pessoaRepositorio.ExcluirEndereco(conexao, transacao, idEndereco);
            });
        }

        // Recebe string e ID do aluno, executando o comando SQL
        private static void ExecutarExclusaoAluno(
            MySqlConnection conexao, MySqlTransaction transacao, string sql, int idAluno)
        {
            using (MySqlCommand comando = new MySqlCommand(sql, conexao, transacao))
            {
                // Adiciona o parâmetro do ID do aluno à consulta SQL
                comando.Parameters.AddWithValue("@id", idAluno);

                comando.ExecuteNonQuery();
            }
        }

        private static Aluno MapearAluno(MySqlDataReader leitor)
        {
            // LeitorMySql é um leitor de dados do MySQL
            // que permite acessar os resultados de uma consulta SQL
            Aluno aluno = new Aluno
            {
                IdAluno = LeitorMySql.Inteiro(leitor, "id_aluno"),
                Observacao = LeitorMySql.Texto(leitor, "observacao"),
                DataMatricula = LeitorMySql.Data(leitor, "data_matricula"),
                DiaVencimento = LeitorMySql.Byte(leitor, "dia_vencimento", 10),
                Situacao = LeitorMySql.Texto(leitor, "situacao", "Sem matrícula"),
                IdMatricula = LeitorMySql.Inteiro(leitor, "id_matricula"),
                Modalidades = LeitorMySql.Texto(leitor, "modalidades", string.Empty),
                Professores = LeitorMySql.Texto(leitor, "professores", string.Empty)
            };

            aluno.Pessoa = new Pessoa
            {
                IdPessoa = aluno.IdAluno,
                IdEndereco = LeitorMySql.Inteiro(leitor, "id_endereco"),
                Nome = LeitorMySql.Texto(leitor, "nome"),
                DataNascimento = LeitorMySql.Data(leitor, "data_nascimento"),
                Cpf = LeitorMySql.Texto(leitor, "cpf"),
                Rg = LeitorMySql.Texto(leitor, "rg"),
                Email = LeitorMySql.Texto(leitor, "email")
            };

            aluno.Endereco = new Endereco
            {
                IdEndereco = aluno.Pessoa.IdEndereco,
                Numero = LeitorMySql.Texto(leitor, "numero"),
                Cep = LeitorMySql.Texto(leitor, "cep"),
                Complemento = LeitorMySql.Texto(leitor, "complemento")
            };

            aluno.Telefone = new Telefone
            {
                IdPessoa = aluno.IdAluno,
                NumeroTelefone = LeitorMySql.Texto(leitor, "telefone", string.Empty)
            };

            return aluno;
        }

        private static bool AlunoExiste(
            MySqlConnection conexao,
            MySqlTransaction transacao,
            int idAluno)
        {
            // Consulta SQL para verificar se o aluno existe no banco de dados
            const string sql = "SELECT EXISTS(SELECT 1 FROM aluno WHERE id_aluno = @idAluno);";

            using (MySqlCommand comando = new MySqlCommand(sql, conexao, transacao))
            {
                // Substitui a palavra chave pelo ID do aluno no comando
                comando.Parameters.AddWithValue("@idAluno", idAluno);

                //Executa o comando SQL e retorna true se encontrar o aluno
                return Convert.ToInt32(comando.ExecuteScalar()) == 1;
            }
        }

        private static void InserirRegistroAluno(
            MySqlConnection conexao,
            MySqlTransaction transacao,
            int idAluno,
            string observacao)
        {
            const string sql = @"
                INSERT INTO aluno (id_aluno, observacao)
                VALUES (@idAluno, @observacao);";

            using (MySqlCommand comando = new MySqlCommand(sql, conexao, transacao))
            {
                // Substitui as palavras chave pelos valores do aluno no comando
                comando.Parameters.AddWithValue("@idAluno", idAluno);
                comando.Parameters.AddWithValue("@observacao", ValorOuNulo(observacao));

                comando.ExecuteNonQuery();
            }
        }

        private static void AtualizarObservacao(
            MySqlConnection conexao,
            MySqlTransaction transacao,
            int idAluno,
            string observacao)
        {
            // Atualiza a observação do aluno no banco de dados
            const string sql = @"
                UPDATE aluno
                SET observacao = @observacao
                WHERE id_aluno = @idAluno;";

            using (MySqlCommand comando = new MySqlCommand(sql, conexao, transacao))
            {
                // Substitui as palavras chave pelos valores do aluno no comando
                comando.Parameters.AddWithValue("@observacao", ValorOuNulo(observacao));
                comando.Parameters.AddWithValue("@idAluno", idAluno);

                comando.ExecuteNonQuery();
            }
        }

        private static void InserirMatriculaInicial(
            MySqlConnection conexao,
            MySqlTransaction transacao,
            int idAluno,
            byte diaVencimento)
        {
            // Insere a matrícula do aluno com a data de hoje e situação "Ativo"
            const string sql = @"
                INSERT INTO matricula (data_matricula, dia_vencimento, situacao, id_aluno)
                VALUES (@data, @dia, 'Ativo', @aluno);";

            using (MySqlCommand comando = new MySqlCommand(sql, conexao, transacao))
            {
                // Substitui as palavras chave pelos valores do aluno no comando
                comando.Parameters.AddWithValue("@data", DateTime.Today);
                comando.Parameters.AddWithValue("@dia", diaVencimento);
                comando.Parameters.AddWithValue("@aluno", idAluno);

                comando.ExecuteNonQuery();
            }
        }

        private static void AtualizarMatriculaAtiva(
            MySqlConnection conexao,
            MySqlTransaction transacao,
            Aluno aluno)
        {
            // Consulta SQL para buscar a matrícula do aluno
            const string sqlBuscar = @"
                SELECT id_matricula FROM matricula
                WHERE id_aluno = @idAluno AND situacao = 'Ativo'
                ORDER BY id_matricula DESC LIMIT 1 FOR UPDATE;";

            object idMatricula;
            using (MySqlCommand comando = new MySqlCommand(sqlBuscar, conexao, transacao))
            {
                // Substitui a palavra chave pelo ID do aluno no comando
                comando.Parameters.AddWithValue("@idAluno", aluno.IdAluno);

                // Executa o comando SQL e retorna o ID da matrícula
                idMatricula = comando.ExecuteScalar();
            }

            // Verifica se encontrou uma matrícula para o aluno
            if (idMatricula == null || idMatricula == DBNull.Value)
            {
                InserirMatriculaInicial(conexao, transacao, aluno.IdAluno, aluno.DiaVencimento);
                return;
            }


            // Atualiza o dia de vencimento da matrícula do aluno
            const string sqlAtualizar = @"
                UPDATE matricula
                SET dia_vencimento = @dia
                WHERE id_matricula = @idMatricula;";

            using (MySqlCommand comando = new MySqlCommand(sqlAtualizar, conexao, transacao))
            {
                // Substitui as palavras chave pelos valores do aluno no comando
                comando.Parameters.AddWithValue("@dia", aluno.DiaVencimento);
                comando.Parameters.AddWithValue("@idMatricula", Convert.ToInt32(idMatricula));

                comando.ExecuteNonQuery();
            }
        }
    }
}
