using System.Collections.Generic; // Listas
using Stingray.BancoDeDados;
using Stingray.DadosTela;

namespace Stingray.Repositorios
{
    // Consulta a programação semanal exibida no Dashboard
    public class DashboardRepositorio : RepositorioMySqlBase
    {
        public List<ProximaAulaDashboard> ListarTurmasDaAgenda()
        {
            // Consulta SQL para obter as turmas com dia da semana e horário de início
            const string sql = @"
                SELECT t.modalidade, t.dia_semana, t.horario_inicio, p.nome AS nome_professor
                FROM turma t
                INNER JOIN professor pr ON pr.id_professor = t.id_professor
                INNER JOIN pessoa p ON p.id_pessoa = pr.id_professor
                ORDER BY t.dia_semana, t.horario_inicio, t.modalidade;";

            return ConsultarLista(sql, null, leitor => new ProximaAulaDashboard
            {
                Modalidade = LeitorMySql.Texto(leitor, "modalidade"),
                DiaSemana = LeitorMySql.Texto(leitor, "dia_semana"),
                HorarioInicio = LeitorMySql.Hora(leitor, "horario_inicio"),
                NomeProfessor = LeitorMySql.Texto(leitor, "nome_professor")
            });
        }

        public ResumoDashboard ObterResumo()
        {
            // Retorna a quantidade atual de alunos, professores e turmas cadastrados
            const string sql = @"
                SELECT (SELECT COUNT(*) FROM aluno) AS total_alunos,
                       (SELECT COUNT(*) FROM professor) AS total_professores,
                       (SELECT COUNT(*) FROM turma) AS total_turmas;";

            return ConsultarUnico(sql, null, leitor => new ResumoDashboard
            {
                TotalAlunos = LeitorMySql.Inteiro(leitor, "total_alunos"),
                TotalProfessores = LeitorMySql.Inteiro(leitor, "total_professores"),
                TotalTurmas = LeitorMySql.Inteiro(leitor, "total_turmas")
            }, new ResumoDashboard());
        }
    }
}
