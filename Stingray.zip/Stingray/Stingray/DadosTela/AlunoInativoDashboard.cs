namespace Stingray.DadosTela
{
    public class AlunoInativoDashboard
    {
        public int IdAluno { get; set; }
        public string Nome { get; set; }
        public decimal PercentualFaltas { get; set; }
    }
}
