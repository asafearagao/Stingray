using System;

namespace Stingray.DadosTela
{
    public class EstadoWhatsApp
    {
        public bool IntegracaoAtivada { get; set; }
        public bool UltimoEstadoConectado { get; set; }
        public DateTime AtualizadoEm { get; set; }
    }
}
