using System;

namespace Stingray.DadosTela
{
    public class TurmaAlunoLinha
    {
        public int IdTurma { get; set; }
        public string Modalidade { get; set; }
        public string DiaSemana { get; set; }
        public TimeSpan HorarioInicio { get; set; }
        public TimeSpan HorarioFim { get; set; }
        public string NomeProfessor { get; set; }
        public decimal ValorMensal { get; set; }
    }
}
