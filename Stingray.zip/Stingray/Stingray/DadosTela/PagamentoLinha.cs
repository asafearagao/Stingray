﻿using System;

namespace Stingray.DadosTela
{
    public class PagamentoLinha
    {
        public int IdMensalidade { get; set; }
        public string NomeAluno { get; set; }
        public string Turmas { get; set; }
        public DateTime MesReferencia { get; set; }
        public DateTime DataGeracao { get; set; }
        public DateTime DataVencimento { get; set; }
        public decimal Valor { get; set; }
        public string Situacao { get; set; }
    }
}
