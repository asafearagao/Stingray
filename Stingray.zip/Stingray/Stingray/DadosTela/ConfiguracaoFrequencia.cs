namespace Stingray.DadosTela
{
    public class ConfiguracaoFrequencia
    {
        public int QuantidadeAulas { get; set; }
        public decimal PercentualFaltas { get; set; }
    }
}
