﻿using System;
using System.Collections.Generic;
using MySqlConnector;
using Stingray.BancoDeDados;
using Stingray.DadosTela;

namespace Stingray.Repositorios
{
    public class PagamentoRepositorio : RepositorioMySqlBase
    {
        public int GerarMensalidades(DateTime dataGeracao)
        {
            DateTime referencia = new DateTime(dataGeracao.Year, dataGeracao.Month, 1);
            const string sql = @"
                INSERT IGNORE INTO mensalidade
                    (mes_referencia, data_pagamento, data_geracao, data_vencimento, valor, situacao, id_matricula)
                SELECT @referencia, NULL, @geradaEm,
                       DATE_ADD(@referencia, INTERVAL (m.dia_vencimento - 1) DAY),
                       SUM(t.valor_mensal), 'Pendente', m.id_matricula
                FROM matricula m
                INNER JOIN (
                    SELECT DISTINCT id_matricula, id_turma
                    FROM turma_matricula
                ) tm ON tm.id_matricula = m.id_matricula
                INNER JOIN turma t ON t.id_turma = tm.id_turma
                WHERE m.situacao = 'Ativo'
                  AND m.id_matricula = (
                      SELECT MAX(m2.id_matricula)
                      FROM matricula m2
                      WHERE m2.id_aluno = m.id_aluno
                  )
                GROUP BY m.id_matricula, m.dia_vencimento
                HAVING COUNT(DISTINCT tm.id_turma) > 0;";

            return ExecutarComando(sql, comando =>
            {
                // Substitui palavra chave por variável
                comando.Parameters.Add("@referencia", MySqlDbType.Date).Value = referencia;
                comando.Parameters.Add("@geradaEm", MySqlDbType.DateTime).Value = dataGeracao;
            });
        }

        public List<PagamentoLinha> ListarTodos(DateTime hoje)
        {
            const string sql = @"
                SELECT me.id_mensalidade, me.mes_referencia, me.data_geracao,
                       me.data_vencimento, me.valor,
                       CASE WHEN me.situacao = 'Pendente' AND me.data_vencimento < @hoje
                            THEN 'Atrasado' ELSE me.situacao END AS situacao_exibida,
                       p.nome AS nome_aluno,
                       COALESCE(GROUP_CONCAT(DISTINCT t.modalidade ORDER BY t.modalidade SEPARATOR ', '), 'Sem turma') AS turmas
                FROM mensalidade me
                INNER JOIN matricula m ON m.id_matricula = me.id_matricula
                INNER JOIN aluno a ON a.id_aluno = m.id_aluno
                INNER JOIN pessoa p ON p.id_pessoa = a.id_aluno
                LEFT JOIN turma_matricula tm ON tm.id_matricula = m.id_matricula
                LEFT JOIN turma t ON t.id_turma = tm.id_turma
                GROUP BY me.id_mensalidade, me.mes_referencia, me.data_geracao,
                         me.data_vencimento, me.valor, me.situacao, p.nome
                ORDER BY me.data_geracao DESC, p.nome;";

            return ConsultarLista(sql, comando =>
            {
                // Substitui palavra chave por variável
                comando.Parameters.Add("@hoje", MySqlDbType.Date).Value = hoje.Date;

            }, leitor => new PagamentoLinha
            {
                // Variável = função.tipo(leitor, "nome da coluna", valor padrão)
                IdMensalidade = LeitorMySql.Inteiro(leitor, "id_mensalidade"),
                MesReferencia = LeitorMySql.Data(leitor, "mes_referencia"),
                DataGeracao = LeitorMySql.Data(leitor, "data_geracao"),
                DataVencimento = LeitorMySql.Data(leitor, "data_vencimento"),
                Valor = LeitorMySql.Decimal(leitor, "valor"),
                Situacao = LeitorMySql.Texto(leitor, "situacao_exibida"),
                NomeAluno = LeitorMySql.Texto(leitor, "nome_aluno"),
                Turmas = LeitorMySql.Texto(leitor, "turmas", "Sem turma")
            });
        }
    }
}
