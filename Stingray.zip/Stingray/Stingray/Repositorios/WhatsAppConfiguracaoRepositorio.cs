﻿using System;
using Stingray.BancoDeDados;
using Stingray.DadosTela;

namespace Stingray.Repositorios
{
    public class WhatsAppConfiguracaoRepositorio : RepositorioMySqlBase
    {
        public EstadoWhatsApp ObterEstado()
        {
            const string sql = @"
                SELECT integracao_ativada, ultimo_estado_conectado, atualizado_em
                FROM configuracao_whatsapp
                WHERE id_configuracao = 1;";

            return ConsultarUnico(sql, null, leitor => new EstadoWhatsApp
            {
                IntegracaoAtivada = Convert.ToInt32(leitor["integracao_ativada"]) == 1,
                UltimoEstadoConectado = Convert.ToInt32(leitor["ultimo_estado_conectado"]) == 1,
                AtualizadoEm = Convert.ToDateTime(leitor["atualizado_em"])

            }, new EstadoWhatsApp());
        }

        public void SalvarEstado(bool ativado, bool conectado)
        {
            const string sql = @"
                INSERT INTO configuracao_whatsapp
                    (id_configuracao, integracao_ativada, ultimo_estado_conectado)
                VALUES (1, @ativado, @conectado)
                ON DUPLICATE KEY UPDATE
                    integracao_ativada = VALUES(integracao_ativada),
                    ultimo_estado_conectado = VALUES(ultimo_estado_conectado),
                    atualizado_em = CURRENT_TIMESTAMP;";

            ExecutarComando(sql, comando =>
            {
                // Substitui palavra chave por variável
                comando.Parameters.AddWithValue("@ativado", ativado ? 1 : 0);
                comando.Parameters.AddWithValue("@conectado", conectado ? 1 : 0);
            });
        }
    }
}
