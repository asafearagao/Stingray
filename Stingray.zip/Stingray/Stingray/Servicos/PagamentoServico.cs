﻿using System;
using System.Collections.Generic;
using Stingray.DadosTela;
using Stingray.Repositorios;

namespace Stingray.Servicos
{
    //
    // Falta coisas aqui, porque o pagamento deve ser gerado e não só exibido o valor
    // Sabe para criar um para cada mês
    //
    public class PagamentoServico
    {
        private readonly PagamentoRepositorio repositorio = new PagamentoRepositorio();

        public int GerarMensalidades(DateTime dataLocal)
        {
            if (dataLocal == DateTime.MinValue)
                throw new ArgumentException("Informe uma data de geração válida.", nameof(dataLocal));

            return repositorio.GerarMensalidades(dataLocal);
        }

        public List<PagamentoLinha> ListarTodos(DateTime hojeLocal)
        {
            return repositorio.ListarTodos(hojeLocal);
        }
    }
}
