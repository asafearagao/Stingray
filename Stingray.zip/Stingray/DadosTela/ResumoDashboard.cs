namespace Stingray.DadosTela
{
    public class ResumoDashboard
    {
        public int TotalAlunos { get; set; }
        public int TotalProfessores { get; set; }
        public int TotalTurmas { get; set; }
    }
}
