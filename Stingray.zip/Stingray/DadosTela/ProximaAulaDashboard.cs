namespace Stingray.DadosTela
{
    public class ProximaAulaDashboard
    {
        public string Modalidade { get; set; }
        public string DiaSemana { get; set; }
        public System.TimeSpan HorarioInicio { get; set; }
        public string NomeProfessor { get; set; }
        public System.DateTime DataHora { get; set; }
    }
}
