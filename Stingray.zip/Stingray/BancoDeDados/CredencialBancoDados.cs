using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Stingray.BancoDeDados
{
    internal static class CredencialBancoDados
    {
        // Caminho do arquivo de credencial do banco de dados, armazenado na pasta de dados do usuário
        private static string CaminhoArquivo
        {
            get
            {
                return Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "Stingray",
                    "Seguranca",
                    "mysql.cred");
            }
        }

        // Obtém a senha do banco de dados MySQL
        public static string ObterSenha()
        {
            if (!File.Exists(CaminhoArquivo))
            {
                throw new FileNotFoundException(
                    "A credencial do banco de dados não foi encontrada.",
                    CaminhoArquivo);
            }

            string conteudo = File.ReadAllText(CaminhoArquivo).Trim();

            if (string.IsNullOrWhiteSpace(conteudo) || conteudo.Length % 2 != 0)
            {
                throw new InvalidDataException(
                    "O arquivo de credencial está vazio ou possui um formato inválido.");
            }

            byte[] dadosProtegidos = ConverterHexadecimal(conteudo);
            byte[] dadosOriginais = null;

            // Descriptografa os dados protegidos usando a API de proteção de dados do Windows
            try
            {
                dadosOriginais = ProtectedData.Unprotect(
                    dadosProtegidos,
                    null,
                    DataProtectionScope.CurrentUser);

                return Encoding.Unicode.GetString(dadosOriginais).TrimEnd('\0');

            } finally {

                Array.Clear(dadosProtegidos, 0, dadosProtegidos.Length);

                if (dadosOriginais != null)
                {
                    Array.Clear(dadosOriginais, 0, dadosOriginais.Length);
                }
            }
        }

        // Converte uma string hexadecimal em um array de bytes
        private static byte[] ConverterHexadecimal(string texto)
        {
            byte[] resultado = new byte[texto.Length / 2];

            try
            {
                for (int i = 0; i < resultado.Length; i++)
                {
                    resultado[i] = Convert.ToByte(texto.Substring(i * 2, 2), 16);
                }

            } catch (FormatException erro) {

                throw new InvalidDataException(
                    "O arquivo de credencial não contém hexadecimal válido.", erro);
            }

            return resultado;
        }
    }
}
