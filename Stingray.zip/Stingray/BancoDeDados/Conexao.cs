﻿using System;
using MySqlConnector;

namespace Stingray.BancoDeDados
{
    public static class Conexao
    {
        private static MySqlConnectionStringBuilder CriarConfiguracao()
        {
            return new MySqlConnectionStringBuilder
            {
                // Configurações de conexão com o banco de dados MySQL
                Server = "127.0.0.1",
                Port = 3306,
                Database = "teste_projeto",
                UserID = "stingray_app",
                Password = CredencialBancoDados.ObterSenha(),
                ConnectionTimeout = 10,
                DefaultCommandTimeout = 30,
                Pooling = true,

                // Desabilita a criptografia SSL
                SslMode = MySqlSslMode.Disabled,

                // Permite a recuperação da chave pública do servidor, necessária para autenticação
                AllowPublicKeyRetrieval = true
            };
        }

        // Abre uma conexão com o banco de dados MySQL usando as configurações definidas
        public static MySqlConnection Abrir()
        {
            var conexao = new MySqlConnection(CriarConfiguracao().ConnectionString);

            try
            {
                conexao.Open();
                return conexao;
            }
            catch
            {
                conexao.Dispose();
                throw;
            }
        }

        // Testa a conexão com o banco de dados MySQL e retorna uma mensagem de status
        public static bool Testar(out string mensagem)
        {
            try
            {
                using (var conexao = Abrir())
                using (var comando = new MySqlCommand("SELECT 1", conexao))
                {
                    comando.ExecuteScalar();
                }

                mensagem = "Conexão com o banco de dados estabelecida.";
                return true;
            }
            catch (Exception erro)
            {
                mensagem = "Não foi possível conectar ao MySQL. " + erro.Message;
                return false;
            }
        }
    }
}
